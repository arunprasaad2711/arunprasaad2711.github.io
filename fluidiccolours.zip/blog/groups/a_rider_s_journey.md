A Rider\'s Journey
==================

| Oh, mighty road! Take him to new places!
| He has enough fuel, to lit all his dreams.
| 
| Ask yourself during your journeys,
| What does your heart want?
| While the roads lead to new places,
| Follow your heart, your true GPS!
| 
| The roads ahead have many stories.
| Many new faces and many sweet memories.
| Pull the throttle, and put on your helmet,
| Take a ride, and leave a trail!
| 
| Keep travelling as always, as the roads are plenty.
| In the journey of life, getting lost is okay.
| But never forget to keep riding,
| To keep riding with all your heart!
| The journey on the outside will help you,
| Find your true self on the inside!
