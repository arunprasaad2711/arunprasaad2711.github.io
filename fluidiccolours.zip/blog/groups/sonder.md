Sonder
======

| You and I are quite similar.
| In an incident, we crossed paths,
| With a billion walking, in this mystical world,
| Why did we meet? Is this destiny?
| 
| I am to you, what you are to me,
| A stranger in a corner, and drinking tea,
| A close friend, or kith and kin,
| An acquaintance, or a well-wisher,
| 
| The love of my life, or my greatest foe,
| Or a passerby in a train, sitting near a window,
| Someone I wished but never realised,
| A bad dream or a passing cloud,
| 
| The roles are complex, diverse, and plenty,
| It is strange we met, among many,
| While my life is full, rich, and unique,
| I am to you, what you are to me.
