Let it go
=========

| When the dreamer in you, tells you to go,
| While the realist in you, tells you to let go,
| The conflict will be an intense tug of war,
| The torn heart with scars the spoils-of-war.
| 
| There is admiration in trying, and being persistent,
| Wiping all your sweat, and trying to be consistent.
| How long can you, put up such resistance?
| When the other side offers, very little insistence?
| 
| Somethings in life, though you made no fault,
| You can\'t do much, and you fail by default.
| The dreamer in you hoped something different,
| Even the realist in you was ready to be belligerent.
| 
| Amidst the darkness, cries the heart in loneliness,
| It was hopeful and eager, among life\'s wilderness.
| There is nothing wrong if you can\'t carry on,
| You\'ve tried your best, it\'s time to move on.
| 
| When you started the journey, there was no map,
| It was unfortunate, that life gave you a tight slap.
| How long can you walk, carrying all the past?
| Burdening your injured heart, healing under a cast?
| 
| You are brave and strong, to hold on very long,
| It is time to let go, and there is nothing wrong.
| It does not mean, you don\'t care anymore,
| It means you choose, to love yourself more.
