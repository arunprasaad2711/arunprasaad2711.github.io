More than what meets the Eye
============================

| I saw you that day by mere chance,
| And I chose to give you a glance.
| What can happen between us?
| We are mere passengers in this life bus.
| 
| You are a whole universe all by yourself,
| A unique book from a library bookshelf.
| Trying to know you by reading every page,
| You are one enigma bound to no cage.
| 
| At the onset of our journey, I was quite scared,
| Seeing your wounds I realised you\'re scarred!
| Life was never smooth and rosy as they say,
| It is hard for all to keep our problems at bay.
| 
| It is a risk and quite a gamble,
| To approach you looking at your preamble.
| Will I see meadows, rivers, and fruit trees?
| Or a barren desert, with a scorching land breeze?
| 
| I only see glimpses of what you are,
| To know you more I need to travel so far!
| There is an urge in me to not to say goodbye,
| You are more than what meets the eye!
| 
| It takes patience and faith to make the call,
| To try and know you and risk losing it all.
| I undress my soul with all my guards down,
| I show myself true don\'t shoot me down!
