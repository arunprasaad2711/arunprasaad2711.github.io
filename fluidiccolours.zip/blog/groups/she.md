She
===

| She was the angel, who made me cry and smile,
| She is my princess, I asked all my life,
| She made my lover a queen, and me a king,
| She is my happiness and also my pride.
| 
| She is competing, with me for attention,
| She does console, when I cry or at loss,
| She was there sharing, her childhood with me,
| She is here to care, for me with all her heart.
| 
| She was there with me, sharing a journey,
| She was the support, I could rely on,
| She is a rival, that I can never defeat,
| She knocks sense to me, whenever I stray.
| 
| She charmed her way to my heart,
| She still dreams, for both our future,
| She is my love and I'm her lover,
| She stands with me through tough times.
| 
| She smiled, when I cried for the first time,
| She was there happy, when I took my first step,
| She was anxious, for nine moons in life,
| She is proud, and always there for me.
| 
| She was the one, who taugh me the world,
| She instilled me with hope, to achieve my dreams,
| She poured into me her knowledge of many years,
| She might forget me, but I can't forget her.
| 
| She gave my mother, a wonderful childhood,
| She was a companion, and competition to her,
| She is the confidant, to my mother even today,
| She is there for me, as a second mother.
| 
| She was the one who told me stories,
| She poured into me her wisdom of ages,
| She defended me from her daughter's rules,
| She was strong as steel, yet frail as a twig.
