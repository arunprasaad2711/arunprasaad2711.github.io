Inward Journey
==============

| There exists a side,
| As big as a tide,
| Hiding in the dark,
| Like a beautiful Lark.
| 
| Lurking in a corner,
| Peeping out further,
| I gathered all my hope,
| To take a lope.
| 
| I stand at the edge,
| Thinking of a pledge,
| To walk on the road,
| And make stories untold.
| 
| I once locked my heart,
| Suppressed all my art,
| My heart felt a void,
| And I never enjoyed.
| 
| I am ready to leap,
| To explore deep,
| I won\'t be a shadow,
| I\'ll bask in the meadow.
| 
| I see an open road,
| I dropped my past load,
| I leapt into a spree,
| The journey set me free.
