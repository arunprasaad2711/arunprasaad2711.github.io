Grace in Defeat
===============

| You hoped it gets lighter,
| But it always became tighter,
| The moment you win,
| The bar raises, higher and higher.
| 
| With few to tell what went wrong,
| You pull yourself out of the abyss,
| Still shaken from the fall before,
| Trembling and rattling, you keep walking.
| 
| The shattered heart feels the worst,
| To stay confident amidst turbulent times,
| To be mad amidst the epiphany of a realist,
| To choose the road less travelled.
| 
| The victor gets many laurels,
| But there is a Grace in Defeat.
| It\'s easy to smile when you win,
| Can you do that in your defeat?
| 
| Your heart yearns rest, but the show will go on,
| And hence you persist picking your battles wisely.
| Growing wise and humble, with every defeat,
| Less scared and less broken in spirit.
| 
| Oh dear universe, give me the strength!
| To let go of the battles, I can\'t win with grace,
| To keep the embers burning, in the ones that matter,
| And to be wise to know the difference.
