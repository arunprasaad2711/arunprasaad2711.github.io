Rakshabandhan
=============

| Blood or by bond, now we\'re kith and kin,
| Even with different feathers, we flocked together,
| Met by chance, united by destiny,
| Our hearts beat in sync, even when we\'re far.
| 
| In your presence, everything feels fine,
| In your absence, everything feels amiss,
| You pull me to light when I am in the dark
| You showed me hope, in this cruel world.
| 
| My confidant, my traitor, my fan, my critic,
| My trustee, my liability, my light, my darkness,
| My friend, my foe, my companion, my rival,
| My angel, my devil, my blessing, my curse.
| 
| I\'ll pull you down when you act all mighty,
| And push you up, when you feel all lost,
| I tease you a lot; I might make you sad,
| But I genuinely care, in crisis, I\'ll be there!
