Autumn Colours
==============

| You come today, and the sun became truant,
| Your winds do bring, the scent of the ground.
| In all of the summer, I played my heart\'s content,
| With your cool touch, you made me retreat.
| 
| Why are you sad?, I always do ponder,
| Whenever you come, you cry your heart out.
| The days of dampness, dark and gloomy,
| The falling leaves, and vibrant colours.
| 
| You are a mother, to this curious child,
| And just like you, I keep changing.
| Many keep saying, that you are a fall,
| To me, you\'re necessary, the force of balance.
| 
| As I sit near the window, I see your tears flow down,
| A strange wonder and awe fill my inner heart.
| You made me sit and travel dimensions with books,
| For that, I am grateful, and I can never repay you!
