Perspective
===========

| I am unlovable and deserve loneliness.
| A thought that I will never accept is that,
| I am alright, and I will find love.
| When push comes to shove,
| I am incomplete and full of flaws.
| I used to believe a delusional lie that,
| Anyone can find love if they try.
| If life has taught me something, it's that,
| Only some are blessed to be happy.
| And you can say a lot to convince me that,
| I have what it takes to find love.
| I have realised after many struggles that,
| I am cursed, and I don't deserve happiness.
| No matter what happens I can't accept that,
| There is a lot of goodness within me.
| Whenever I search my feelings, I wonder,
| Am I destined to a long cold life?
| 
| (Now read from bottom to top!)
