Festival of Lights
===================

| On this epic day, were justice prevails,
| The light overcomes dark and persists,
| Nothing is great and fulfilling but,
| The warm company of kith and kin,

| Let the heavenly light gaze your homes,
| And spread its charm in all your lives,
| To all friends, family and all,
| A very Happy deepavali!
