It is never easy
================

| It is quite a test, that pushes all your buttons,
| Whenever he or she, asks those questions,
| In their odd ways, they do quite care,
| But in the process, they break and make you.
| 
| It is quite easy, to take them as your enemy,
| They do disagree, to a lot you say,
| Most of us are, quite fortunate that,
| They are not, indeed your enemies.
| 
| They did give birth, to you in this world,
| And for a long time, you didn\'t know any better,
| So they took it upon, themselves to raise you,
| And it is quite hard, for them to step back.
| 
| And when you start to grow, the struggles begin.
| And within a matter of time, you fight against them.
| You have the youth, and resilience to spring back,
| They have their wisdom and worldly caution.
| 
| With time, in this changing world,
| The struggle is real, to put forth your points.
| Amidst many arguments, and many expectations,
| In the heated debates, the egos clash.
| 
| It is quite an irony, in the journey of life,
| How often the people you love tend to hurt you.
| But despite the fights, most of us are lucky,
| As they are the ones, who love you the most.
| 
| Raising kids was never an easy task,
| With changing times, there were no rules,
| As you grow up, you thought they knew it all,
| As you mature, you see the plight they faced.
| 
| While they do care, they have their demons,
| Demons of expectations, fears and insecurities,
| Some made sense and some will not,
| Despite the obscurity, they love you truly.
| 
| As you grow old, you start to empathise,
| And try to reconcile, the differences you have,
| You take a deep breath, and let go the anger,
| In the moments of silence, you step in their shoes.
| 
| You realise that it\'s long and hard learning,
| You learnt a lot, and still, have a lot to learn.
| You tread carefully, and sensibly as possible,
| And in those moments, you feel their burden.
| 
| You and them might be poles apart,
| Both you and they care deeply for the other,
| It is, however, the flaws in us and the words,
| That pushes and pulls both you and them.
| 
| Sometimes you wonder, can\'t it be easy?
| It is in some cases; it isn\'t in some cases,
| There is no winner in these fights all the time,
| As long as no one is left helpless and alone.
