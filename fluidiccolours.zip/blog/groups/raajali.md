Raajali
=======

| I look up in the sky,
| To see you fly by,
| You spread your wings wide,
| Majestic as a king by my side.
| 
| With eyes very sharp,
| You dive near a scarp,
| Catching prey at sight,
| With a strong might.
| 
| Basking in the sky all day,
| I have no words to say,
| All the awe and wonder I see,
| I am jumping like a kid with glee.
| 
| Little does anyone know,
| What it took to bestow,
| Such wonder is your gift!
| And speed so vibrant and swift.
| 
| Share your vision with me,
| And grant your focus to me,
| So I may never lose track,
| When I need to go off track.
| 
| Share your grace with me,
| And grant your demeanour to me,
| So I may handle my rise with grace,
| And be calm during disgrace.
| 
| Share your strength with me,
| And grant your wings to me,
| So I may stay strong and fly,
| And never quit to try.
| 
| Share your hope with me,
| And grant your courage to me,
| So I may pass through troubles rife,
| And fly above the storm of life.
