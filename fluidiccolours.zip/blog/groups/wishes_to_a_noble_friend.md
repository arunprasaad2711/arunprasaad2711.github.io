Wishes to a Noble Friend
========================

| The White moon is shining,
| Following wherever you go!,
| Surprisingly for you and unknown to all,
| The moon carried the stars for you!
| 
| While you walk in your journey ahead,
| With no time to stop and look,
| The moon shall stop and make you speak,
| With pleasant dews in pure heart,
| 
| Let the path you go shall be known to all,
| As a path that all shall dare to take,
| Forging your road you shall gallop ahead,
| Gentle as the breeze and wild as a mustang,
| 
| Your life shall fill with lively colours,
| Pink in health and White in heart,
| With rosy smiles and lively eyes,
| The world will be from violet to red!
| 
| As you walk in your journey ahead,
| Companions many shall journey aside,
| I wish them all to be cheerful as you,
| With bonds so strong like the larks themselves,
| 
| I wish for a day, soon in the wild,
| When the moon shall be, a person indeed,
| Sweeping your feet off and stealing your heart,
| You shall be together like the bread and butter,
| 
| Together as a couple, while your love blooms,
| Out shall come the songs, sweet as your hearts,
| Melting the world and charming the time,
| Nature in ease, will make you live in peace,
| 
| As you take a leap ahead,
| Be grateful to all who helped,
| As you climb the ladders for glory,
| I am prideful with your epic story!
| 
| Like the warm sun that lights the world,
| Like the pleasant moon that guides the awe,
| Live long and prosper for years!
| My dear and noble friend!
