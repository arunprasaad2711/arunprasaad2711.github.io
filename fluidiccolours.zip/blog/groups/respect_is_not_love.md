Respect is not Love
===================

| It is in humans, to talk about valour,
| About seeking glory, and finding honour.
| When you reach a summit, others shall admire,
| For you reached a goal, others will desire.
| 
| Those who seek you then, may not fan your flame,
| Drawn to all the name, and the spotlight of fame.
| At the end of the day, this is a number\'s game,
| We\'re enticed to play, although it is quite lame.
| 
| It is quite a paradox, when you see it this way,
| With many to admire, yet none to see you that way.
| As you shine bright, they see a perfect image,
| Unaware of the depth, and many many rummage.
| 
| If you think that is love, then you are quite wrong,
| Although they respect you, and even sing a song.
| It takes a lot of wisdom, to push your fame aside,
| And see you who you are, and love you with pride!
| 
| When you stand and shine, people will respect you,
| Ask you for favours, and many offers from you.
| While there is respect, this is not love they send,
| You are a salvation, a mere means to an end.
| 
| Respect and love, are two different feelings,
| Both can co-exist, deep in a heart\'s dwellings.
| Respect can make possible, for true love to flourish,
| But respect is not love, that\'s a message to cherish.
