A Sweet Voyage
==============

| I thought about the day when we first met,
| It is not so vivid; the details were blurry,
| But the feelings we felt, were crystal clear,
| We didn\'t realise, the sweet voyage ahead.
| 
| It wasn\'t a beginning, as in a fairy tale,
| It is quite common, but still feels special.
| Both did think, that we might drift away,
| Yet I stayed back, and so did you.
| 
| Despite the journeys and paths we travelled,
| We had a lot of ideas in common,
| The patience to nurture, a robust, powerful bond,
| A passion for making a difference in the world.
| 
| A loyalty so strong, it stands tall against any crisis,
| The drive to help the other, when the other is lost,
| A sense of justice, and what\'s right and wrong,
| A shared flavour for humour and ideas boundless.
| 
| When lost in thoughts and plans for the world,
| One became the teacher the other the student,
| You taught me a lot, and I taught you too,
| Both helped each other, to find our inner selves.
| 
| What events will life throw, I have no clue,
| But amidst all that is variable, there is one constant,
| That for me is your valuable friendship,
| That I shall do my best to preserve till the end.
