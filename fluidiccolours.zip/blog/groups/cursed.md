Cursed
======

| In the eerie quiet night, I hear your heartbreak,
| Echoing loud and clear, deafening my solitude,
| It was my fault; I let you near me,
| I thought I was ready; I felt we could make it,
| 
| There is a void in my soul, where you once stayed,
| A pit so deep, even an abyss feels small,
| A void so old, and so very cold,
| I feel numb, and I feel lost,
| 
| Many people afar, told me I was cold,
| When they came near, they told me I am warm,
| I warned them not to come, anymore near me,
| They came closer, and I burnt their dreams,
| 
| I pray to the universe, to put me far away,
| For I am cursed, and my breath reeks death,
| I am sorry I hurt you, I care for you,
| This is a curse I can\'t, find a way to break.
