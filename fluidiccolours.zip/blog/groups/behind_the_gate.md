Behind the Gate
================

| In all my wanderings, in my one singular quest,
| I sought knowledge, without any rest.
| Little did I expect, for the truth to be so stark,
| With infinite perspectives, like a storyline's arc.
| 
| The truth is a circle, without a beginning or end,
| Still, Yet through its strokes, it has the knowledge to send.
| The circle maintains a flow, and serves as a balance,
| To let the energy flow, without any imbalance.
| 
| In it there are markings, and exotic drawings,
| And many obscure paintings, and prideful writings.
| These myriad inscriptions, add colours to the truth,
| Painting a picture of suffering, pain and ruth.
| 
| Still, the truth set me free, gave me the power to be God,
| I became arrogant and challenged God as a fraud.
| In my naive foolishness, I tried to break the rules,
| And the price I had to pay, I had no clues.
| 
| The truth opened a gate, and pulled me inside,
| Where I saw a being, without a form outside.
| It's a bone-chilling smile, I remember forever,
| The darkest secrets of life, I remember forever.
| 
| For my blatant errors, and my avarice,
| I lost a lot, and it's a painful sacrifice.
| Still, the secrets I saw, and the lessons I learnt,
| Do greatly help me, though I am burnt.
| 
| That is when I realised: not all rules are lies,
| Some maintain balance; without it, we'll die like flies.
| The universe has a flow that you must understand,
| Before you deconstruct, you must comprehend.
| 
| Only when you comprehend, can you understand,
| To deconstruct and reconstruct, with your hand.
| To use this power demands equivalent exchange,
| And that is the truth, of this universe quite strange.
