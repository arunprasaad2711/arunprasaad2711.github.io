Still Waters
==================

| I remain quiet, pondering and wondering,
| To find ways, to express the lingering feeling,
| I feel you, with all of my heart,
| And even more, where can I start?
| 
| Yet you couldn't, see my true feelings,
| I was wrong, to assume my callings,
| To be clear, to you as bright as day,
| I was wrong, and couldn't find a way.
| 
| Feelings so intense, that suns feel hot,
| Running quite deep, that oceans shy away,
| Free and limitless, that air feels trapped,
| Yet quite steady, that lands learn patience.
| 
| I was wrong, to think you can feel it,
| It is riotous, even I can't control it.
| It's never easy, for me to express myself,
| It's a blessing, and a curse in itself.
| 
| Hence I pour, my pearls as I see you,
| One by one, in the night thinking of you,
| To find ways, to express my infinite care,
| I muster up, my courage and again dare.
| 
| I remain quiet, and I withhold myself,
| For you'll drown, if you venture all by yourself.
| I am still, a human with a finite heart,
| So I let, my feelings run deep in my art.

