When two Poles meet
===================

| We chatted quite friendly,
| And talked like adults,
| She called me weird,
| I called her even.
| 
| She had good taste,
| And aims unreal.
| My taste was passable,
| And aims ideal.
| 
| Some opinions we had,
| Were opposite and too strong,
| It did clash hard,
| We disagreed very hard.
| 
| Yet we listened calmly,
| And heard the other side,
| Taught eachother things,
| The other did not know.
| 
| Amidst the storm of words,
| A new bond formed,
| A beautiful friendship,
| Respecting the differences.
| 
| The respect was mutual,
| The talks were unusual,
| A balance does strike,
| When two poles meet.

