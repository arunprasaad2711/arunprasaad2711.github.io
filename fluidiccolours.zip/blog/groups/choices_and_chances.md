Choices and Chances
===================

| It happened randomly, they all write,
| As if the universe, conspired to make them meet.
| It is an Illusion, is all it is,
| Only a little truth, that\'s all there is.
| 
| If love is random and happens by chance,
| Will it matter if you try it or not?
| What shall be, the difference it makes?
| For those who pursue, and pour in their soul?
| 
| Love, you are, a mystical enigma!
| Despite a million tales, you are still elusive!
| Source of awe, wonder, and peace,
| Reason for disgust, disaster, and violence.
| 
| You happen to many, at precarious times,
| Breaking their hearts, and tainting their souls.
| You happen, for some in odd times,
| And thrive and flourish, in ways never thought.
| 
| For some who seek, they get tested to the core,
| For some, you come, taking their breath away.
| For some who seek, end up all alone,
| For some, you come, at the right moments.
| 
| You tempt us all, with all that is rosy,
| Showing us the tales, of many twin flames.
| That\'s not the way; it happens to all,
| Some who believe it, they break and fall.
| 
| You make two souls meet, who are fitting pieces,
| The flower doesn\'t blossom, and sees the day,
| You make two souls meet, who are unfit pieces,
| The flower blossoms, rots, and withers.
| 
| You make two souls meet, who are fitting pieces,
| For one it blossoms, for the other it doesn\'t,
| And make the bloomers wonder, what\'s this sorcery?
| Left with no answer, forced to find closure.
| 
| For some, it happens, gradual and natural,
| From unknown to friends to buddies to sweethearts.
| Blurring the lines gracefully and smooth,
| Nurtured and built, with time and space.
| 
| For some, it happens, as if a fairy tale,
| With many intimate moments and many fantasies,
| It ends bitter, like a quenched hot steel,
| The heart does shatter, like broken glass.
| 
| Not all your tales have a happy ending.
| Not all those who found you, cherish you till the end.
| Some end what is theirs, for greener pastures,
| While some change a lot, they don\'t fit anymore.
| 
| It is a tragedy to see, a good broken heart,
| A heart once full of hopes, stitching its pieces.
| Filled with pain, and walls so high,
| Scared to trust, and cautious than before.
| 
| It is sad to see, a good heart so lonely,
| A heart that yearns, for the joys of intimacy.
| Feeling low and cold, and learning from falls,
| Trying hard to be strong, despite the let downs.
| 
| Are you that fickle? That you happen by chance?
| And you are fragile, tender yet dangerous.
| Are you so chaotic? That you are unpredictable?
| After making us win, you break us to be humble?
| 
| Despite the turbulence, you bring forth,
| And amidst the chaos, you show us an order.
| Despite the shipwrecks, you show us some joy,
| Making our lives hard, with or without you.
| 
| The stars do align, for some people proper,
| With time and space, everything falls in place.
| For some they make, the stars to align,
| For they can\'t wait, as you never visited them.
| 
| It takes courage, to fall in love hard,
| To fall so madly, and fall so deeply.
| It takes, even more, to pick your shattered heart,
| And stitch it back in place, and move on.
| 
| It takes strength to stay strong, and keep going on,
| To find The One you yearned, all the way long.
| Swimming up the river, against the cross-currents,
| Trying not to drown, in the stream of life.
| 
| All the love that formed, out of lies and disguise,
| May start well at first, but it will break off.
| Not long can you wear, a skin different from yours,
| At the core of it lies, all the issues in disguise.
| 
| Love once happened can wither with time as well,
| And it can boom back, with the same soul or other.
| A love formed of truth, built with trust and kindness,
| With passion and maturity, is deep and beautiful.
| 
| You do get to choose, whom you\'ll fall in love,
| For reasons right or wrong, the choice is all yours.
| Welcome to the real world, it is blurry and grey,
| And love is quite messy, yet you want it anyway.
