Maybe it's not meant to be
==========================

| Often you see, people around you,
| Walking their lives, without any clue,
| They have goals, ambitions and dreams,
| Done at the cost of silencing the screams.
| 
| Trying to fit their lives, to the rules of the world,
| Forgetting to nurture, their true inner world.
| It is no wonder, their heart screams out loud,
| For it has nothing, to be truly proud.
| 
| Some people chose, to let the universe decide,
| Hoping its grand plan and their lives coincide.
| It is mere stupidity or arrogance I can't decide,
| To give up so meekly is similar to suicide.
| 
| It is true that the world has its own rules,
| That does not mean, we have to be mules.
| If you let someone else, to make decisions for you,
| You will meet issues, popping out of the blue.
| 
| While the world is harsh, there is some hope,
| And to catch that ray, one should dare to lope.
| It is quite scary, and it may not end well,
| Yet you have closure, and a brave story to tell.
| 
| It is foolish to say: maybe it's not meant to be,
| Before trying anything and that's clear to see.
| If everything is easy, there is no point in trying,
| If everything is easy, what's the point in living?
