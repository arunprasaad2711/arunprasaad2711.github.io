Cold Fire
=========

| You felt its presence, yet you weren't scared,
| At the beginning, you ignored, as it was timid,
| If you searched your feelings, the signs were there.
| Yet you mistook it, for a warm, gentle fire.
| 
| All the flames you've seen were quick to kindle,
| They were easy to trigger and innately direct.
| I feel sorry for you, that you kindled the wrong fire,
| This one is not warm; rather it is cold.
| 
| While the flame you see often, is orange and hot,
| Loud and greedy, passionate and bright,
| This flame is hotter, intense and blue,
| Silent and ruthless, with nothing to hold back.
| 
| Nothing burns brighter, than the coldest of flames,
| Even its embers are cold and sharp as ice.
| For that is the reason, it refuses to kindle,
| When it starts to burns, even ashes cease to exist.
| 
| The warm flame shows, a spectrum of emotions,
| The cold flame is stoic, distant and plain.
| Often quite patient, scared of its powers,
| Test it too much, it will ignite without warning.
| 
| Be humble and gentle, honest and genuine,
| It will be warm and gentle and makes your life vital.
| Be arrogant and harsh, dishonest and fake,
| When the time comes, it'll burn you with indifference.
