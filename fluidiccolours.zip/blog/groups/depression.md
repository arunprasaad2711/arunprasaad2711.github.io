Depression
==========

| In the calmest of nights, I prayed for peace,
| The peaceful silence became a scream,
| The blissful solitude became the worst of foes,
| The ever normal heart, beaten with insanity.
| 
| They saw my wings, but didn\'t see the chains,
| I fought to break; I got torn instead,
| We all face it, they said in chorus,
| Having never suffered a void in their hearts,
| 
| The nights filled with sleepless worries,
| My past demons dancing in my dreams,
| Selling your soul to get some sleep,
| You wake up empty, with disregard and apathy,
| 
| A prisoner in your mind, you see the world real,
| Drowning in your sorrow, you cry for help,
| I don\'t want my grief to overflow to others,
| Said my heart in pain, as I sunk slowly into a grave.
