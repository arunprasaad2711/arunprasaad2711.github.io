Unopened Doors
==============

| There was a breeze,
| It blew between trees,
| Thawed my heart old,
| Rusty and cold.
| 
| Finding trust is very rare,
| Earlier I didn\'t care,
| I wandered here and there,
| I couldn\'t find it anywhere.
| 
| This breeze I saw,
| Made my heart thaw,
| I then had a light,
| My future was bright.
| 
| I was kind and warm,
| Ever happy and calm,
| Like a fruit with a worm,
| My life had a storm.
| 
| Navigating at all cost,
| I found myself lost.
| All the aims I dreamed,
| Many got shipwrecked.
| 
| I dig my thoughts deep,
| On many nights I weep,
| In that pain I became cold,
| Unrelenting and bold.
| 
| Amidst all deception,
| I saw a conclusion.
| The ridings were rough,
| The tidings were tough.
| 
| Without any digress,
| I worked for progress,
| My life turned around,
| It became pretty sound.
| 
| Amidst all the laughter,
| There was a missing chapter,
| That\'s when I saw you,
| My heart beats for you.
| 
| A feeling so gentle,
| It blossomed to kindle,
| I fancied a big duet,
| And I became a poet.
| 
| Oh, Gulmohar flower,
| With your witty fervour,
| Please don\'t kill me!
| Please don\'t hang me!
| 
| I mustered up my courage,
| After days of forage,
| And gave you a flower,
| For you to be my lover.
| 
| My heart stood like a rock,
| Feelings I had felt a block,
| I realised that you\'re a wall,
| Built on rocks strong and tall.
| 
| I thought you\'d say yes,
| And never did I guess,
| You would say no,
| My guts said so.
| 
| I accepted in grace,
| And gave you some space,
| But I stayed in touch,
| My feelings held in a clutch.
| 
| In the distance I admired,
| What your heart desired,
| Watched your subtle grace,
| The thoughts you embrace.
| 
| Amidst a turbulent time,
| My heart did rhyme,
| And longed to say your name,
| And stir a passionate flame.
| 
| With patience, I waited,
| My thoughts seated,
| Having tested time,
| Hoping your heart be mine.
| 
| I gathered a lot of courage,
| Than what I could forage,
| I knocked on the door again,
| Despite the pouring rain.
| 
| The door didn\'t budge,
| Not even a nudge,
| But I gained a trust,
| Firm and robust.
| 
| I saw a glimpse,
| The thoughts you eclipse,
| A glimpse of many years,
| Sum of many fears.
| 
| I saw you up-close,
| You\'re beautiful prose!
| Many ups and downs,
| Echoing many sounds.
| 
| What can I honestly say?
| If you don\'t feel that way?
| I can\'t force you to sway,
| But it\'s hard to move away!
| 
| In the moments I feel sad,
| Your thoughts drive me mad.
| With my feelings unclad,
| I felt terrible and bad.
| 
| I prayed to the universe,
| For you to find your verse,
| For many a laurel,
| And friends so loyal.
| 
| With a heavy heart,
| I take a fresh start,
| I have been so hard,
| On myself and scarred.
| 
| You did not feel that way,
| After all, I had to say,
| Though my heart is in a sway,
| I decided to move away.
| 
| I see my heart in pain,
| Of injuries deep and plain,
| I drift away to heal,
| And many voids to seal.
| 
| I sail away far and wide,
| I have many waves to ride,
| I am always a riser,
| I keep growing wiser.
| 
| If you feel for me later,
| Do write a big letter,
| Come out and take a walk,
| Let\'s meet out and talk.
