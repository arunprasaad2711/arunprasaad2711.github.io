No one
======

| A man with no name,
| Is playing a secret game.
| Is it for name or for fame?
| His life never the same.
| 
| He has an inner flame,
| That is hard to tame.
| Feeling neither guilt or shame,
| For him both are the same.
| 
| Who is he knows no one,
| But looks normal like anyone.
| Works alone without someone,
| He moves on waiting for none.
| 
| A mysterious past he has one,
| Made mistakes quite a tonne.
| Accepting the past with regrets none,
| He silently plans till it\'s done.
