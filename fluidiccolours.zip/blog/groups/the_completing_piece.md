The Completing Piece
====================

| A mother, a sister, an aunt, a friend,
| A granny, a teacher, a niece, a daughter,
| A crush, a lover, a wife, a woman,
| A girl, a leader, a nurturer, a bride ...
| 
| How many roles do you take?
| In each role you play a part.
| Without you there is no we,
| And there is no future to see.
| 
| You are strong and you are brave,
| You are kind and you are caring,
| You are smart and you work hard,
| You are inspiring and thus you are beautiful.
| 
| You are there in every step of my life,
| You make this world fascinating and complete.
| You being happy is a treasure for us all,
| For your well-being is vital to all.
| 
| A progress obtained by suppressing you,
| Never gave an everlasting happiness.
| For the world that is full of happiness,
| Both of us must lift each other up.
| 
| Neither of us are truly equal,
| Yet neither of us are truly different.
| Neither of us are superior to the other,
| Yet neither of us are inferior to the other.
| 
| Regardless of where our lives may go,
| Both of us have our roles to play,
| Both of us have our own goals,
| Yet both of us can't walk alone.
| 
| It is not because we both are weak,
| It is because we are stronger together,
| Let's plan and work and build together,
| For our lives and future to be bright.
