You will reap
=============

| All that is random will make sense,
| All the loose ends, will one day connect,
| The time will come, and your wait will end,
| The bounty you seek shall be plenty.
| 
| All your efforts will now bear fruits,
| The world will see, and praise your efforts,
| Though you're lost, you'll find your way back,
| The ones you desire will fulfil.
| 
| All your struggles will polish you,
| And you will glow, more than mere glitter,
| Your frozen heart, will one day thaw,
| And the embers will burn, brighter than ever.
| 
| The love in your heart will spring again,
| All the withering hopes will rise again,
| You will visit, all the places you dreamt,
| And the world will sing, of your beautiful tale.
| 
| A fire shall rise, from the ashes like a phoenix,
| The fire in your heart will give out light,
| The light will push, all your shadows away,
| And it will conquer, all your demons forever.
| 
| All these hardships and pains shall pass,
| Your winter will break, and your spring isn't far,
| All the seed you've sown will rise from the ground,
| And they shall bear fruits, that you will reap.
