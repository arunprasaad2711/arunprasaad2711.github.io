Said He, Said She
=================

| May I ask said he
| You may said she
| I like you said he
| I can\'t said she
| 
| May I ask said he
| I\'m broken said she
| So am I said he
| I\'m scared said she
| 
| I\'m not insisting said he
| I know that said she
| You trust me said he
| Yes I do said she
| 
| Why scared said he
| Of the past said she
| It\'s different said he
| Can\'t see it said she
| 
| Have faith said he
| It\'s hard said she
| What isn\'t said he
| I don\'t know said she
| 
| Who am I said he
| A good friend said she
| I wanted more said he
| I can\'t give said she
| 
| I respect you said he
| Thank you said she
| I won\'t insist said he
| You never did said she
| 
| Want went wrong said he
| Nothing was said she
| Then what said he
| I didn\'t feel said she
| 
| It\'s hard said he
| I know said she
| I\'m hurt said he
| Me too said she
| 
| Who are we said he
| We are friend said she
| Nothing more said he
| Nothing less said she
| 
| Should I wait said he
| No move on said she
| Why not said he
| It\'s cruel said she
| 
| If I moved said he
| It\'s alright said she
| I\'ll feel different said he
| I\'ll be happy said she
| 
| Am I bad said he
| No you\'re not said she
| I feel clueless said he
| That\'s life said she
| 
| It\'s awkward said he
| Don\'t be said she
| You\'re relaxed said he
| I know you said she
| 
| Is there hope said he
| I don\'t know said she
| If there is said he
| I\'ll ask you said she
| 
| I\'m going said he
| Why so said she
| To heal said he
| Come back said she
