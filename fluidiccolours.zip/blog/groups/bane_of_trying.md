Bane of Trying
==============

| Sitting calm and quiet, you hear the universe speak,
| Of all the plans it has, for you quite sleek.
| If what you sow, is what you reap,
| Will it all come true? All the dreams in your sleep?
| 
| Trying to make hay, while the sun is shining,
| You put all efforts, hoping for a silver lining.
| While it is true, that time waits for none,
| If you\'re hurt and broken, can anything be won?
| 
| Somethings in life, are not so straight,
| You might have to, sit and wait.
| You cannot plant a seed, today and be ready to reap,
| All the harvest tomorrow, and keep them in a heap.
| 
| Like the wet clay a potter, uses to make pottery,
| Things will take shape as if it\'s sorcery.
| Yet even the pots made, need some time to dry,
| For that, you must wait, and keep a watchful eye.
| 
| Rushing the steps fast, or pushing it too hard,
| You might kill the very thing; you seek so hard.
| There is some wisdom, in moving slow and steady,
| When the stars align, you will be quite ready.
| 
| You might get what you seek when you try very hard,
| But when you are not ready, retaining it is very hard.
| You\'ll miss little things, while trying without waiting,
| The restlessness is the price, the bane of trying.
