Solitude
========

| In the calm of the night,
| A drop of sadness lingered,
| But oddly it was soothing,
| And the pain began easing,
| 
| While the world kept running,
| Time froze still,
| A flurry of emotions came,
| And receded like a tide,
| 
| Amidst the emptiness,
| My thoughts grew loud,
| As I let them go,
| I found peace and happiness,
| 
| In the noise of the world,
| I love this moment,
| A moment of bliss,
| Time for solitude.
