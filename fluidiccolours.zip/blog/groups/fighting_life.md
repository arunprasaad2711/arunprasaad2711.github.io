Fighting Life
=============

| The journey of a man is always enigmatic,
| Through thick and thin a purpose is in need,
| While a few succeed and many fail bad,
| The river of life never stops for a break,
| 
| The world is full of masked actors,
| With so many roles in so many plays,
| Masking and masking all life long
| Till there is nothing novel to share,
| 
| The valiant mind is the biggest joke,
| For it goes on amidst a massive storm,
| Through deserts and tides and thorny vines,
| Life is hardest for the strongest to go,
| 
| In the quest of life, in search of a purpose,
| While many fail to stand against time,
| With broken bones and bloody knuckles,
| Life must move for the strongest of all,
| 
| Let the truth be that I am strong,
| Residing in winter and forging my spring,
| Deception, Evil, Pain or Grave,
| Nothing can break my Godly game!
