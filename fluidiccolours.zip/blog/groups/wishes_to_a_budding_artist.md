Wishes to a Budding Artist
==========================

| While all of us see colours,
| You leapt to use them,
| When we think the world is grey,
| You showed the colours we couldn\'t see,
| 
| How does it feel? To view the world,
| In all its best, in all its worst?
| To see every little thing, even the soul?
| And choose to mimic the magic it has?
| 
| You are no god, but I see a resemblance,
| When your works convey, a deeper meaning,
| Nuanced yet straightforward, with attention to detail,
| I admire your effort; I find it endearing,
| 
| As you step forward, ready to leap,
| I wish you all success and an abundance of health,
| Keep the embers burning, and the colours flowing,
| Happy birthday to you, my budding artist!
