Wild Lily
=========

| I have charm, to win my foes over,
| Wild and crazy, yet gentle and naive.
| I am independent, a walking sensation,
| With a touch of the devil, in an angelic heart.
| 
| I smile so brightly, the sunflowers look at me,
| I dance with joy, in the rainiest of days.
| When I walk with anger, the very land trembles,
| When I am happy, I float like a feather.
| 
| The breeze is my friend, carrying my scent across,
| Don\'t try to bind me; I\'ll never be yours.
| See my nature, the good and ugly side,
| Touch my soul; my heart is yours.
| 
| A spark always twinkles, in my black eyes,
| A spark of love, a spark for mischief.
| I am the laughter, you hear through the forest,
| Blossoming above the pond, I am a wild lily.
