Love under the Stars
====================

| Holding your hands, we walked the coast,
| In the candlelight dinner, we had a toast.
| From twilight to midnight, the moments were right,
| You\'re in my sight, beautiful and bright!
| 
| Meeting your eyes, and seeing the twinkle,
| I shower my love, like a water sprinkle.
| Holding you up close, like a gentle rose,
| You\'re the woman I chose, a wonderful prose.
| 
| Just like last night, before midnight,
| Let\'s make it right, and travel out of sight!
| No one to find us, and the stars to guide us,
| Just the two of us, and no worldly fuss.
| 
| In the middle of nowhere, in a moment so rare,
| With consent, I dare and kiss you with care.
| With a sensual caress, let us undress,
| With much love to express, let\'s not digress.
| 
| The night was calm, and you were warm,
| With our eyes to confirm, we rhymed uniform.
| Amidst the sandy dust, we quench our lust,
| With nothing to adjust, hearts full of trust.
| 
| I want to get lost, like a tiny little frost,
| I want you to get lost, like a tiny little frost.
| And find each other, inside each other,
| We\'ll be together, and this bond is forever.
