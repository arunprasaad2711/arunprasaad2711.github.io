New Beginnings
==============

| I am leaping,
| Moving far and away,
| My ship is waiting,
| My time is fleeting,
| 
| My heart is heavy,
| Filled with memories,
| But my journey beckons,
| And I must go on,
| 
| A nomad I came,
| With no strings attached,
| Then why is it hard,
| To leave detached,
| 
| I am going high,
| My heart racing fast,
| For fear of falling,
| For fear of leaving,
| 
| The nights of solitude,
| The jokes and sadness,
| The days of sunshine,
| And countless desires,
| 
| I came here once,
| To leave a mark,
| But now I feel,
| The place marked me,
| 
| I want to say,
| That I love you,
| A million miles away,
| I will think about you,
| 
| Wish me luck my friend,
| I am writing a new chapter,
| This is just a comma,
| And our lives will cross again,
