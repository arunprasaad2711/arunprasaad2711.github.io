It's time for Spring
=====================

| The truant sun that played hide and seek,
| Lost the game, and chose to work again,
| For the days are now, no longer weak,
| The lake that became icy started to thaw again.
| 
| All the dreams I had, in the womb of winter,
| Now matured well, and began to germinate.
| I should've waited, and tried for them later,
| The cold winds iced my dream's fate.
| 
| The dream in my winter was hope for spring,
| The dream that I clung to, without an end near.
| The winds of winter, have made me quite strong,
| It made me worthy, of the gifts spring bears.
| 
| In the cold struggle, in the absence of light,
| I struggled hard, to find an easy path.
| Now I am strong and much more bright,
| I now walk freely, and I forge my path.
| 
| An autumn child I am, I was born amidst change,
| Close to the day, when the sun was fair with light.
| Conceived in the cold, amidst changes quite strange,
| I chose to fight, the darkness and be bright.
| 
| Trembling in the cold, I made my fire,
| Amidst the darkness, I found my light,
| And my frozen dreams started thawing in the fire,
| My spring is nearby, and it is quite bright.
