Blessed
=======

| How many journeys have I voyaged before?
| In all the lives before?
| How many journeys will I voyage after?
| In all the lives after?
| 
| I have no count, nor can I keep one,
| For my past lives are histories,
| Written on scrolls, dried and decayed,
| Powdered and lost in the dust.
| 
| I have no count, nor can I keep one,
| For my future lives are mysteries,
| Waiting to be written, and make a mark,
| On the vast flowing river of time.
| 
| Amidst the past and the future,
| Lies my present - my great gift,
| With parts of my journey written and tracked,
| With parts of my journey waiting to be marked.
| 
| I am but a hollow vessel,
| Whose existence is mere happenstance,
| In the grand scheme of the universe,
| I am but an insignificant stardust
| 
| With your touch I found purpose,
| This hollow vessel became a flute.
| With the life breath, you infused in me,
| My soul resonated, and music came out.
| 
| If I am insignificant, then why do I feel,
| Your indomitable presence in my soul?
| In those instances, when you bless me,
| I feel like a child, born to rule the skies.
| 
| The music that came out from my soul,
| As it flew across valleys and hills,
| Resonated and resonated with every living soul,
| All at once, in a grand unison.
| 
| Whenever I felt lost and empty,
| You answered my prayers and shared your breath.
| I lost count you filled my soul,
| Yet you keep giving, again and again.
| 
| With every gift, my melodies became sweet,
| It grew strong and diverse and deep,
| Although my heart, though quite finite in size,
| It fully felt your blessings, quite infinite in size.
| 
| My joy knew no bounds nor any limits,
| Whenever I was blessed, the feeling was ineffable,
|  Unknown to me, despite the countless melodies,
| There was room, in my heart to sing more.
| 
| Years shall pass, and I shall get weak,
| Sticks and stones can break my bones,
| But I shall stay strong and make melodies,
| I am blessed by your sacred touch.
