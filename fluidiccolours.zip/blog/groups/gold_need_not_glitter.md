Gold need not Glitter
=====================

| An unsettled restlessness, lingered in the air,
| A need to be heard, and accepted by the crowd,
| A misplaced sense of what's right and wrong,
| A heart quite insecure that it can't remain calm.
| 
| While the world can be harsh, it is gentle too,
| You can see the ground, or choose to see the stars.
| Don't hope to see the stars by looking down,
| Nor by belittling others, can you climb quite high.
| 
| You can be the loudest, and a fierce cut-throat,
| But your success is fuelled by emptiness.
| A desire so material, and a heart so shallow,
| While you journey through, you burn bridges down.
| 
| You think you deserve and feel so entitled,
| Tell me one thing, what is it you desire?
| Your arrogance and greed, all blinds your path,
| Then you sit and search when it is too late.
| 
| While the world can be harsh, kindness is a virtue,
| If you see it as weakness, you have no hope.
| You might put many masks, and shine so bright,
| You might glitter and glimmer, but you're not gold.
| 
| It takes strength to be kind, in a world so harsh,
| Great changes are quiet, and often very patient.
| All that is gold need not always glitter.
| As glitter does not define, what gold truly is.
