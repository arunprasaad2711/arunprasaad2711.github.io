Life\'s Purpose
===============

What is a life\'s Purpose?

As humans, it is deeply ingrained in our lives to look for a purpose.
So, let\'s take a moment and try to answer it.

So what is a purpose? Simply put, it is a utility. As the Proverb
\"Necessity is the Mother of Invention\" rightly quotes, necessities
drive us to accomplish a remarkable number of things in the world.
Gifted with intelligence, we humans can put our mind into action to
achieve wonders. Right from stone age till current times, this necessity
remains with us, and it will probably live with us for the foreseeable
future.

We have wallets with us to carry money safely. We build homes to stay
protected and comfortable. Likewise, everything we humans have made and
kept has some purpose.

That said, what is our purpose in our life? Why are we born in this
life? What is the use of our existence?

This question has been a philosophical question for aeons, manifesting
itself in various religions throughout the world, a regularly debated
topic of discussion in spirituality, literature, science, arts etc.,
Yet, with countless debates, treatises, etc., the question still alludes
us for all the nuances it carries.

So, is there a definite answer? No.

Fine, is there any answer at all? Plenty.

Many religions say that the purpose of a human\'s life is to serve the
Almighty God. Some people say the meaning of life is to exist merely.
Some say the purpose is to contribute something to the world we live.
Many say money is the purpose of life.

While all the purposes mentioned above are at the least, points towards
an end goal, some argue that life has no meaning at all.

We can sit in front of each other, and have lengthy debates as to whose
statement is right or wrong, even try to disprove the other\'s comments.

If we were to introspect into ourselves, we still stand in the same
place. The purpose of the question of What is your life\'s Purpose? Will
always be subjective.

Now, let\'s take a detour here; what if we decide to live a life that
has no purpose at all? What will happen to us? As tempting as it is, the
whole world will collapse if each one of us stopped to pursue a purpose.

Despite its mysteries and unknown, I suppose we all can agree one thing:
Humans need a purpose. Without a goal, we have no motivation or drive to
accomplish anything. It gives us meaning; it gives us a reason worthy of
us to strive.

Notice a peculiarity here: This purpose in life is something we all
seek, and we do not fully comprehend, yet it is the drive for us to
live. Without it, we cripple ourselves.

It is human nature to assume everything has a purpose.

The oddly sounding truth is: There need not be any purpose to actions as
well.

Once, I saw a man roaming in front of an ATM to draw money. He was not
educated and hence did not know how to take out cash from his bank
account. He requested me to help him. I obliged. I gestured him inside
the room where the ATM is kept and typed the account number, and the PIN
code to withdraw money. We got the money, and I gave it to him. The
smile he had on his face was sincere, and he thanked me wholeheartedly.
He was happy to get the money out for his needs, and I walked out of the
ATM feeling happy for helping someone out.

This person took the gamble and asked a total stranger to help him get
money out of the ATM. He shared, assuming that I will be truthful, his
confidential account details (bank account number and PIN) to me in the
hopes to get his money out.

What could I have done here? First, I might have refused to help him
because I see no purpose in this for myself. Or, I could have behaved
wickedly, and after assisting this man in, I could have swindled his
money. Or I might have refused to consider his plea for help and moved
on.

I could have done any one of the above things here. So, why did I help
this man? You may ask. He was struggling and asked several people to
help him. Many refused. I was saddened to see him suffer like that. He
might have needed that money for a variety of reasons. Him persisting in
asking people to help him only implied that whatever purpose he had in
his mind, it was for something of great importance.

So, is this my purpose in life? That is to help a random stranger? Not
necessarily.

But, my actions have done some good for someone. That means something.

It meant me a small token of happiness, although, for a fleeting moment,
it might have been a life-saving grace for him. It might have been
something too trivial, or something of urgent need. For him, my simple
kind gesture might mean more than mine.

The point I am driving through this example here is simple: Our actions,
despite having a purpose or not have consequences. It can be good or
bad. For now, that is irrelevant.

Good actions cause goodness to everyone around us, bad actions bad.

So, what if, we centre our lives around this simple rule? Do good
without anticipating anything in return!

You might argue with me that this rule is impractical as it is not
applicable to all aspects of life. Partly I agree. Now, can you picture
yourself in a situation where you can do good without anticipating
anything in return? Yes? Good! That is a start!

Knowingly or unknowingly, our actions disturb the fabric that
intertwines our lives, like a drop of milk dropped on a calm cup of tea.
Like the ripples that form, our actions travel and touch the lives of
many people around us for the good or bad, for the better or worse.

That said, let me say I have a so-called purpose in life. While I strive
to achieve it and find meaning to it, is it not beautiful if we can
touch other people\'s experiences with gentle acts of kindness?

And that, if you pause and ponder, means a lot. Remember all the times
you felt happy about getting a surprise? You might have been working
hard, beating yourself up in disappointment when miraculously someone
comes by and helps you fix it?

Action and Purpose and Consequence are inter-connected. If our actions
mean no or little consequences, then we tend to take them lightly. On
the other hand, if our actions indicate no purpose, then we tend to
avoid them.

So, what do you aim? What should your life\'s purpose be?

One answer I try my best is to seek happiness. And, it makes sense.
Everyone in the world unanimously agrees and wants to be happy. Despite
having all the riches or laurels or glory one might strive for, at the
end of the day, regrettably, they mean nothing if one is not happy.

Mathematics is a beautiful subject in many aspects. One of the reasons
why is because it has strong foundations; a set of principles that are
consistent, meaningful, and they make immense sense. These foundations
are Axioms. Some of these axioms are so obviously true that you don\'t
need to prove it; the moment you write it down, they make absolute
sense. Some axioms are assumed to be true while proceeding further. If
the assumed axioms alter, that gives rise to new branches in the field
and questioning the assumptions is a fascinating topic altogether. A
similar analogy holds good for science.

Likewise, we build our lives based on some firm foundations. These
foundations shape our attitude towards the world and determine how we
perceive it. But unlike mathematics and science, there is no set of
strong axioms or laws with us. We can forge it on our own. Some
foundations are laid by us borrowing from the society, our parents, our
family, friends, environments etc., Some we put it for ourselves.

The foundations in Mathematics and Science helps us appreciate the
beauty and meaning these fields offer to us. Likewise, the foundations
we build our lives gives us meaning.

This scenario is both good and bad.

If our foundations are faulty, then not only are we unable to see it
clearly but also unable to defend ourselves without seeing
contradictions in the world and within ourselves. If these faulty
premises are removed, something that we might have clung on for a
lifetime, we are pushed into an existential crisis: something that gave
meaning to our lives is now proved wrong, thereby we might start
questioning ourselves as to what we are without it, what is the purpose
of life without it? In our defence and denial, we might cling on to them
even stronger, becoming increasingly hostile to any criticism trying to
disprove it. Sometimes, the revelation breaks us, paralysing us as we
fall into an endless abyss. The fall breaks these people, and they
refuse to rise fearing defeat, while some musters up all the courage in
the world to strive to either prove they are right or accept to build
around a new foundation although cautiously, still tormented and haunted
by the fall. Only a remarkable few rises are again breaking the
constructs, becoming wiser and broader in mind like the endless sky.

On the contrary, the ethical foundations help us grow and evolve and
transform. It gives us a clear purpose and meaning. Even when beaten
down, it serves us as an anchor to keep us unfailing in an ever-changing
world, better, and it gives us the strength to rise again. The stronger
our foundations are proved right, the stronger our will. It gives us
peace, something to lean on, something to strive for, something to
defend for, something to fight! It helps us to bring out the best and
genuine version of ourselves.

This idea is crucial! While there is no assurance that the foundations
we learn from our environment are safe, being self-aware helps us to
correct ourselves when we go wrong.

And therein lies another quality we can strive for: self-improvement.

If one were to strive for something big, something remarkable, something
that can make a difference, something that can make one happy, it is
worth pursuing. And in that pursuit, if one were to improve oneself
continuously, and at the same time, touch people\'s lives for the
better, everyone will be happy. The world will overflow with happiness.

**This, in my opinion, is a higher purpose in life: continually improve
yourself to be a better version, pursue something that gives you
happiness, and through your actions spread the overflowing happiness to
others as well.**

While the aim might be too idealistic, there are indeed limitations,
restrictions, and practicalities that hinder it. All things said and
done, and instead of being a cynic to dismiss the possibility and thus
fail by default, I would rather be an optimist and try failing.
