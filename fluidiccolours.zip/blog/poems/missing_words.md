Missing Words
=============

| You and your friend started walking together,
| Life comes in, and separates you apart,
| Your friend finished the journey you both set out,
| You're happy for him but sad that you couldn't reach there.
| 
| You chose to be brave, and took the leap of faith,
| And you expressed love and your liking to your interest.
| Your interest finds you fine, but doesn't reciprocate,
| Yet something was amiss, that words failed to express.
| 
| You planned quite well, and took all measures,
| You took pains to foresee all the ways,
| For you being human, for you being limited,
| Ran out of words, when your plan failed that way.
| 
| You searched all your life, and went to great lengths,
| To get that one treasure, you yearned all this while.
| The moment you found it, you felt nothing,
| The sacrifices meant nothing, and your purpose felt empty.
| 
| Your wild little heart tried to say something,
| You couldn't understand what your heart said,
| Your fierce little soul wandered here and there,
| Trying to find a reason, and wanders to no avail.
| 
| You are young, yet you felt too old,
| Too tired to carry on, and yet trodded on,
| You wanted to talk, yet felt shame and guilt for that,
| And you went numb until your colours faded and left. 