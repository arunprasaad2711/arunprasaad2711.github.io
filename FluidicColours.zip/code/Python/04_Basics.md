# Basics

## Standard Scientific Libraries
* NumPy
* SciPy
* Matplotlib
* SymPy
