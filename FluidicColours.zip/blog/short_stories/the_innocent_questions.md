The Innocent Questions
======================

Inputs from Sapana Bhasker

It was quite a sunny morning in Ahmedabad. The summer season began, and
the streets were hot. Sitting at home without a fan is quite
uncomfortable. A cool breeze in this hot season is a heavenly gift.

Narendran got up earlier than usual that day. Restless and full of
energy, he ran around the house searching for his mother Susheela and
wish her good morning.

\"Maaaaaaaa!\", he exclaims in a joyous mode, as he stormed into his
parent\'s bedroom.

There, the excitement he had all the while came to a halt; Fear filled
in his heart and he started to worry.

He sees his mother searching for something in the almirah. She was
wearing a saree with a blood stain. On seeing him come, she turns around
with white napkins in her hand.

\"Good Morning, Nandhu!\", his mother smiled at him and hugged him.

Nandhu was still terrified and scared of the blood stain on her
mother\'s saree.

\"Nandhu! What happened, beta?\" his mom asked.

\"Maa, are you injured?\"

\"No beta, I am alright. What happened?\", she asks in concerned.

Still frightened, he points at the blood stain on her saree. His mother
sees that and sighs relief.

\"Oh, Nandhu beta, it is nothing to worry about dear.\" She kisses him
on his cheek and pulls him closer to the bed. She sat on the bed and
made him sit on her lap.

\"Maa, are you alright? Are you hurt?\", he asked finally, now a bit
relieved after consoled by his mother.

\"Yes beta, I am alright. Maa just had her period while sleeping and the
blood stained my saree.\"

\"What is a period maa? Is it like a class period in school?\", Nandhu
asked curiously.

She smiled and ruffled his hair with her hand.

\"Nahi beta, it is not the school period. It is different. Did you
notice Sarika aunty yesterday?\"

\"Yes, Sarika aunty has a baby growing in her belly.\", he answered
curiously.

\"Very good Nandhu. You see, girls after they grow older a bit, their
bodies produce some amount of blood and nutrients.\"

\"So?\"

\"So, this blood and nutrients will help the baby in the girl\'s belly
grow beta.\"

\"Then why does the blood come out?\"

\"You see beta if the baby starts forming, then this blood and nutrients
help the baby to grow. When there is no baby, this blood and nutrients
are not needed. And hence, once in every 28 days, this blood comes out
of the girl\'s body like how susu comes out.\"

\"But, that\'s for girls Maa! You\'re a woman, na? Why is blood coming
out of you?\", he asked sincerely.

Susheela was quite surprised at her son for having such a sharp mind.
Not only Nandhu is quite curious for an eight-year-old, but he is also
sharp.

\"Nandhu beta, girls grow to become woman na? So, after the girl reaches
a particular age, she bleeds for the first time and has her first
period. From then till she reaches about 45 years old, this will
happen.\"

\"So, when will girls start having period ma?\"

\"Well, the age is different for different girls. Some girls get their
first period when they are 11. Some get their first period when they are
16. Most girls get their first period between 11 and 16. I got my first
period when I was 13 Nandhu.\"

\"So, do you get period when you have a baby growing in your belly
maa?\"

\"Nahi beta. When a baby is growing inside, this blood will not come
out. It will help the baby grow.\"

Nandhu grew silent. He was thinking over all these answers her mother
gave.

\"What is it Nandhu?\" his mother asks him again.

\"Maa, I understood all of it. But one thing I don\'t get it is, how is
a baby formed?\" he asked.

Susheela laughed and ruffled his hair again.

\"Nandhu beta, you see Maa and Paa hug affectionately naa? Sometimes,
Maa and Paa have a special hug. When we do that, a baby forms inside
Maa. It is quite difficult to explain what this special hug to you now.
When you get older, I\'ll tell you about it. Okay?\"

\"Okay ma,\", he said. \"I still have three more questions maa.\"

\"Sure beta, ask me!\"

\"First, does it pain when you bleed ma? Second, what is this napkin
for? And third, why are you rolling these bloodstained napkins in the
old newspapers?\"

She took a deep breath and said calmly.

\"Nandhu beta, it does pain. Maa will bleed little each day for 3-4
days. Yes, it does pain. Maa, other women, and girls wear this napkin to
avoid the blood stain on their dresses. Maa forgot to do that last
night, and maa\'s saree got stained.\"

\"The newspapers?\" he asked.

\"The blood in these napkins after a while starts to smell bad and germs
will grow on it. These germs can cause illness to others. Hence I wrap
them up in newspapers and throw them far away.\"

\"But, can\'t you just throw them without rolling them in a newspaper?\"

Susheela got a bit sad and worried. Her son asked an innocent question
that had so much stigma.

\"See beta most women do not talk about this to their boy kids and male
members of their family. A lot of people still see this in a bad way and
are ashamed to talk about this.\"

\"Why maa? What\'s bad in it?\"

\"Honestly, there is nothing wrong here beta. But, a lot of people
don\'t see it that way. I want to tell you this because I don\'t want to
be like other people and hide it.\"

\"Does Paa know all this?\"

\"Yes beta. I tell these to Paa. He is kind and understanding. I tell
this to you because it will help you understand what many women will go
through. In the future, when you get married to a girl, she will have
periods like this. Your friends who are girls will have periods like
this too. At that time, if they are shy or afraid to ask for help, what
will you do?\"

\"I\'ll help them maa!\"

\"Good boy, Nandhu!\".

The mother and son embraced each other affectionately.

That day, without realising what happened, Nandhu the 8-year-old boy got
to know what even grown-up man never got to know.

The innocent questions opened up a new dimension for the kid to know
about women.
