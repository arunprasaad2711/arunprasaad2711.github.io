Vemoedalen
==========

| You worked with care,
| And crafted it all day,
| It is unique you swear,
| And you shout in gay.
| 
| The reality hits you hard,
| When they say it\'s the same,
| You try to explain very hard,
| They still see it the same.
| 
| It is scary this big fear,
| Of your work already done,
| By some unknown stranger,
| Who did it first and won.
| 
| It does make you question,
| Are you truly special?
| It leaves a big impression,
| That you are not so special.
| 
| Thus you strive to be unique,
| To make something new,
| By pushing away the antique,
| In the attempt, you grew.
| 
| In the race to make a difference,
| Running hard to catch attention,
| You do show a lot of indifference,
| To the little things that need attention.
| 
| But there is some comfort,
| To accept that you are normal,
| Do step out from the discomfort,
| And do behave quite informal.
| 
| There is some sameness in everything,
| And what you do might be a repeat,
| When the task is finished and done,
| The experience you gained is a feat!
| 
| Your existence alone is unique,
| The universe conspired to make you live,
| Although one day you\'ll be antique,
| You mark with memories the time you live.
| 
| The photo you took with care,
| Might not be so unique,
| For you, it is quite rare,
| As that one is so unique.
| 
| No matter what a hundred people feel,
| What you will do is unique,
| Your good work will make someone feel,
| That your work is unique.
| 
| So it is alright if you fell in love,
| And spun a tale so cliched,
| The journey you take is all above,
| The jokes and tales so cliched.
