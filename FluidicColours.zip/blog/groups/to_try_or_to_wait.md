To try or to wait
=================

| Fortune favours the bold some say,
| Good things happen for those who wait some say,
| Then why do some who try hard fail?
| Then why do some who wait do fail?
| 
| Things in life are complex, and not quite stark,
| The difference is not apparent, as light and dark.
| There is some truth, in things they both say,
| Also lies some lies, in things they both say.
| 
| Even those who wait, never truly waited,
| They also tried a bit, and never truly seated.
| Even those who tried never kept trying,
| They also rested a while; else they were lying.
| 
| Therein lies the answer, to this conundrum,
| A delicately crafted balance, devoid of any tantrum.
| One should wait when needed, and try when needed,
| And the wisdom to see them is quite needed.
| 
| It is not so easy, to wait in some moments,
| Nor is it easy, to run and grab the moments.
| One must persist, and be ready to recede,
| That is one skill, you gain when you concede.
| 
| Praying towards the universe, I ask for serenity,
| To sail through crisis and times of uncertainty.
| I ask for strength, to try or wait at will,
| An abundance of wisdom, to quickly learn this skill.
