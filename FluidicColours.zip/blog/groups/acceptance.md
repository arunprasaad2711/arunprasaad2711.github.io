Acceptance
==========

| In times of uncertainty,
| I clutched tightly to the past,
| In fear of the unknown,
| For the comfort of the known.
| 
| As I look at the future,
| I see my shadows of the past,
| I look at my hands,
| I see the scars of holding on too long.
| 
| In a fortunate mishap,
| One string detached from my past,
| Rather than fear, I felt lighter,
| And my journey became easier,
| 
| I made mistakes, and I can\'t erase them,
| I can only learn, and move on,
| Learn to drop the burden of the past,
| Wisen with age, more accepting of the unknown.
