Detached
========

| I started to run,
| Even before I could walk,
| There were needs, and time was short.
| 
| The farther I went,
| The finish line went even farther,
| I ran faster, yet nothing in sight.
| 
| My feet bled, sore from pain,
| Everything else became a blur,
| I turn back, and I was all alone.
| 
| Time went fast and slow,
| Days fleeted like minutes,
| Went a long way, still feel I\'ve learnt none.
| 
| Some of my dreams came true,
| But why do I feel so empty?
| And not a smile on my face?
| 
| While I see others, running and happy,
| Can\'t help but feel raging envy.
| Why didn\'t it happen to me?
| 
| Did I go wrong? Take a wrong turn?
| Everything seems out of place.
| The irrational heart asked, why me?
| 
| While I kept running, I forgot,
| To see the scenery, city, and people,
| The curse of never wandering.
| 
| Am I the person I am?
| I feel like an alien to myself.
| Trapped in a world that speaks a foreign tongue.
| 
| Trying to learn the rules of the game,
| It is such a mess and drives me insane.
| Feeling lost in this unending maze.
| 
| Kept running all day, and I lost track,
| Of other pursuits that keep life intact,
| For once I felt I was ready to enact.
| 
| The setting was different, and things were subtle,
| I learnt the alphabets and tried to write,
| The settings wanted prose instead.
| 
| It is hard to keep the embers burning,
| Realising my limits, yet pursuing,
| In an ever-changing world, detached.
| 
| I will keep my embers burning bright,
| Forgo all the weight that pulled me back,
| And I shall pause for a while, here and there.
| 
| Like the ball that sinks in water,
| Amidst all noise, I shall rise,
| For I have many promises to keep.
