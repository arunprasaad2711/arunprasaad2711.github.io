Believe It
==========

| It is easy to discard, and say a goal is hard,
| If everything is easy, then what does a goal mean?
| If it means something to you, why do you wait?
| Take the leap and try, You'll get it! Believe it!
| 
| It is unfortunate when no one understands you,
| And refuses to see it, and discards your work.
| Don't give up, and still proceed forward,
| Be strong and trust yourself! You'll get it! Believe it!
| 
| The journey to your goals is quite hard no doubt,
| The trials and tribulations are quite a lot.
| But in the journey, you'll get more than you ask,
| I have been there, and you'll be there too! Believe it!
| 
| When broken or sad, it is human to cry,
| But you whining and complaining, won't get you far.
| Resist the defeat and overcome your pain,
| And do smile! You'll get your goal soon! Believe it!
| 
| In the cold silence, search all your feelings,
| Reflect upon them deeply, and the answer will be clear.
| For your resolve will be strong, when you have a purpose.
| With that walk, boldly! You'll win! Believe it!
| 
| The world may say, a lot about you,
| But deep down, you have the potential.
| And a light so bright, that outshines the stars,
| Bask in the light, and you'll be happy! Believe it!
