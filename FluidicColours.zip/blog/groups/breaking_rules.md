Breaking Rules
==============

| I was young, naive and bold,
| With many rules, as my stronghold.
| Rules that kept me moving,
| Rules that kept me improving.
| 
| As I grew old, I grew less naive,
| The trials in life filtered me like a sieve,
| These rules and these regulations,
| Became my many invalid foundations.
| 
| How do you feel, about your life?
| When your heart is cut, with a knife?
| These rules once kept me safe,
| As they got outdated, I was attacked by a strafe.
| 
| After many a night, losing faith,
| All the memories flashed like a wraith.
| The rules once I built are not valid,
| Excessively rigid and incessantly pallid.
| 
| Pondering on these thoughts, I do wonder,
| If I had treated, myself a bit kinder?
| Hindsight told me, I would be happy,
| Much more calm, and much less grumpy.
| 
| As I venture further, I am treating myself kind,
| No more to the days, I was stuck in a bind.
| Breaking my many invalid rules,
| I am beginning to see life jewels!
