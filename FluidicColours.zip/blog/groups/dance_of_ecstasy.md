Dance of Ecstasy
================

| As I went higher and higher, the troubles mattered less,
| In the struggle to climb, all my worries faded away,
| Sitting on the mountain, I see more than ever,
| The vast, broad landscapes, the bigger picture of life,
| 
| As I sit and ponder, looking at my journey ahead,
| The path that leads to it gave me a scare,
| But the monsoon clouds, with its soft grey hands,
| Came closer to me and embraced me with hope.
| 
| The winds whispered, wishes in my ears,
| As it caressed my hair, it cooled my soul,
| In a moment of ecstasy, a queer liberation came,
| A child that never flew dared to rule the sky,
| 
| On the ground I was doubtful, now I am clear,
| Like the peacocks in the monsoon rain, I too shall dance,
| As I keep climbing, I'll go higher and higher,
| And all these sorrows, cannot break me forever.
