Where are you?
==============

| In this world, with ever-changing rules,
| I\'m losing hope, and running out of clues,
| Searching far and wide, in every other corner,
| Where are you now? I need you to be closer.
| 
| Some days are hard, without your company,
| The heart often does, misses your symphony,
| How far can I run, away from my reality?
| Where are you now? My life is a tragedy.
| 
| Once I looked, in the Mirror of Erised,
| And I saw your face, the one I desired.
| Will you ever come, the person of my dreams?
| Where are you now? My heart does scream.
| 
| I tried so hard, amidst all odds,
| Even as an atheist, I prayed to all gods.
| I am a broken glass, fallen and shattered,
| Where are you now? I feel quite scattered.
| 
| When did I lose you, I do not know,
| Did I ever have you, I could not know?
| All I do know, is I\'ve felt your fragrance,
| Where are you now? I want your presence.
| 
| My muscles do ache, yet I keep walking,
| On the journey of life, that\'s quite tiring,
| I try hard, to know more my true self,
| Where are you now? My true inner self?
