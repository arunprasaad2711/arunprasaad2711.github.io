Keep Smiling
============

| When life hits you hard,
| Breaks your heart into shards,
| At that moment,
| Keep Smiling.
| 
| When things are hopeless
| And you are clueless,
| At that moment,
| Keep Smiling.
| 
| When the odds do not favour,
| You persist with fervour,
| At that moment,
| Keep Smiling.
| 
| When you have the courage,
| To rise against the discourage,
| At that moment,
| Keep Smiling.
| 
| You know you\'re vincible,
| But giving up is impossible,
| At that moment,
| Keep Smiling.
| 
| You fear because you\'re wise,
| You hide it in disguise,
| At that moment,
| Keep Smiling.
| 
| When you\'re truly scared,
| But persist facing the feared,
| At that moment,
| Keep Smiling.
| 
| The smile you put shall hide,
| All the pain on the inside,
| But it is needed to move onward,
| The needed courage to go forward.
| 
| Though the smile is fake,
| It keeps the hope awake.
| It\'s easy to smile when nothing is at a loss,
| Can you smile when everything is at a loss?
| 
| I can smile despite having nothing,
| I learnt to smile losing everything.
| That surprises people,
| And it amazes me too.
