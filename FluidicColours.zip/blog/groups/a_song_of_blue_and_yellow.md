A Song of Blue and Yellow
=========================

| On a rainless day,
| We push and pull,
| Under the clouds,
| Our mischief begins,
| 
| You were simple,
| My ego told before,
| But you are a puzzle,
| I realise baffled,
| 
| Are you my enemy?
| Are you my friend?
| Why do you love me?
| And hate me together?
| 
| Torn between poles I stand,
| Lost like a raindrop in the sky,
| I swing between joy and sorrow,
| Clueless of the morrow.
| 
| Should I leave? Or should I stay?
| You tell me, my dear,
| For the trauma of the poison of the past
| Don\'t fear the elixir of the future.
| 
| You are the ray of hope,
| Who flashed in my starless sky,
| Adding your shades of vibrant yellow
| To my life filled with mystic blue,
| 
| Hold my hand and fly with me,
| The sky is vast and endless,
| Cherishing your love, I shall pen,
| A Song of Blue and yellow.
