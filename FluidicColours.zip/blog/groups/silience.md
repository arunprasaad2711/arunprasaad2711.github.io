Silience
========

| Now you\'re famous, and everyone speaks of you,
| But when you were new, I never heard about you,
| Walking down the streets, I didn\'t notice you play,
| Now I do wonder, how I missed your grace,
| 
| That made me wonder, is brilliance everywhere?
| Waiting to be discovered, or failed to get noticed?
| As I ponder over, It dawned upon me,
| Indifference is easy, but fighting is hard,
| 
| The struggle is severe, to do what you love,
| When not a soul to see, the beauty in your work,
| Hoping for a break, you valiantly try every day,
| One day will come, and your work will be seen,
| 
| Brilliance is around us, waiting to be found,
| A moment from our lives is all we need to find,
| The next epic artist could live next door,
| Burning the midnight oil, perfecting the craft.
