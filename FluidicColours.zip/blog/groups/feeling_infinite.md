Feeling Infinite
================

| I was lost in space, wandering in time,
| Dwelling on the past, my future was blurred.
| In the depths of darkness, a ray of light emerged,
| A ray of bitter truth, a path of reconciliation.
| 
| The shackles that bounded began to rust,
| My strength emerged; I broke free.
| The severed wings, once again sprouted,
| The freedom tasted sweet, happiness spouted.
| 
| No more I am foolish; I have grown wise,
| Yet my smile was wide, as the deep blue sky.
| I chose to be kind, on myself more,
| I accepted what I can, and what I can\'t do.
| 
| With a new found hope, I dived,
| The winds caressed my feathers, and I flew high.
| In that sweet moment, although I am finite,
| I felt strong to move on, and felt Infinite!
