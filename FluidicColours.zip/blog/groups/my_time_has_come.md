My time has come
================

| The bow is stretched to the yielding limit,
| The axe is now very sharp,
| The wasted carbon was buried deep,
| It was waiting for the grand day.
| 
| The foes are clear, and their strategies are out,
| The wait is over and my time has come,
| All the joharis are now very clear,
| The last few straws are now no more,
| 
| Seneca\'s words came true now,
| And all the fake masks are now torn,
| My rules and religions are now strong,
| Now they shall keep me safe,
| 
| I was buried with a huge burden,
| Which gave me the strength to bear the pain,
| I was innocent to be played with deceit,
| Which helped me learn to tear your mask,
| 
| I wanted help when I suffered a crisis,
| But I received subterfuges in return,
| In the middle of all this rat race and poignancy,
| I regained parts of my windy west childhood,
| 
| The rules you have now,
| Will slowly be shattered,
| In the middle of the turbulence,
| You will question back your faith.
| 
| The arrow ready to fire,
| The axe is ready to cut,
| The carbon is now a diamond,
| Now I shall write your fate!
| 
| Can faint clouds block the sun?
| Can trees obstruct a storm?
| Will hyenas delight with all the fun,
| When a furious lion hunts them?
