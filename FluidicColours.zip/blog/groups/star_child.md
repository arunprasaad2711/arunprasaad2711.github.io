Star Child
==========

| Days will come and days will go,
| The trifles of life can weigh you down.
| Hope may seem bleak and future uncertain, - yet,
| Don\'t settle for the dust, my star child.
| 
| Your blissful solitude may turn to silence,
| Your heart might prefer violence,
| Amidst hardship, defeat and despair,
| Don\'t settle for the dust, my star child.
| 
| When the myriad walls that keep you safe break,
| Making you question your faith,
| Keeping you pondering with sleepless nights,
| Don\'t settle for the dust, my star child.
| 
| At these times, hope may seem faint,
| You might feel well-off being a saint,
| With trials and tribulations seemingly vain,
| Don\'t settle for the dust, my star child.
| 
| When your lookout for love goes barren,
| When drifting friendships make you sad,
| When the gravity of reality weighs on you,
| Don\'t settle for the dust, my star child.
| 
| Days will go, but keep fighting,
| The war will be won, despite a few battles,
| Where is the chase when things go smooth?
| Be strong and move on, my star child.
| 
| Search your feelings in the cold silence,
| You will know that there is no end to violence,
| The harder you burn on the inside,
| The brighter you shine to all my star child.
| 
| Walls can crumble, but ideas cannot,
| Test your faith; it strengthens your resolve,
| Confront the storm with might, my dear,
| You will emerge stronger, my star child.
| 
| Flow like a stream my star child,
| Forge your way, noble and brave.
| All your efforts will come around,
| You\'ll reap bounties far and wide.
| 
| Pursue your passion my star child,
| Lose your self and bask in its glory.
| Your passion will find your lost self back,
| Infinitely strong and wise you\'ll become,
| 
| You are not alone, my star child,
| There are many like you burning inside,
| Amidst pain and suffering, they are bright,
| A symbol they are, that all things not lost.
| 
| Why do we fall? Tell me my star child,
| To master the art of picking ourselves up.
| The bigger you fall, the higher you rise,
| Keep moving; you are in for a surprise.
| 
| You might seem odd, unflagging all alone,
| But your light guides the mortals in their nights.
| Lost in the sea navigating on chunks of dust,
| Finding their way home, in vast never-ending seas.
| 
| Real friends are like stars, my star child,
| Sometimes, they are far far away.
| But they are always around you,
| Even in your darkest night my dear.
| 
| You are the child of sun my dear one,
| Born to accomplish a higher purpose.
| The gravity of it is unfathomable,
| To other mortals who try to eclipse you.
| 
| Your grandparents the cosmos, are there for you,
| Looking after you, through thick and thin.
| As we speak, they listen to your prayers,
| And conspiring an angel for you.
| 
| You will meet the angel from heaven,
| Forged in hellfire, nourished by the elixir.
| You will find love and the whole nine yards,
| So do not be sad, soon, you\'ll be glad.
| 
| You are the child of sun my dear one,
| After every winter, you\'ll face a summer,
| So don\'t settle for the dust, my star child,
| For you are the substance that makes suns!
