The Soul Catcher
================

| Many days I walked, alone and restless,
| Chasing my dreams, hard and endless,
| Ever trying my best, to complete fullness,
| Trying to fill a void, a deep emptiness.
| 
| You don\'t speak a word, you sleep,
| Your kind face forever, in my heart I\'ll keep,
| You wipe my tears, whenever I weep,
| Let me sing a song, for you to rest deep.
| 
| Like the eyelids to the eye, I will be close to you,
| Protecting you from harm, I shall be with you,
| Till you break your rest, my eyes won\'t rest for you,
| That is the least I can, always do for you.
| 
| I asked the flowers: Is this a dream?
| To have you in my life, in joy I scream!
| Adding joy to my life, you are a stream,
| Whenever we kiss, you taste like cream.
| 
| I curse the autumn winds that give you the cold,
| As you sleep in sickness, ill care for you until I\'m old,
| I bless the summer winds that made me so bold,
| To meet you and tell, what my heart truly told.
| 
| As you lie in my lap, I am reading a book,
| A book so dear to you that I\'ll never overlook.
| I wonder and ponder, what did it take,
| Your precious little heart, to get such a hook?
| 
| My heart once wandered, hither and thither,
| Drifting in the wind, like a lonely feather,
| Changing its emotions, just like the weather,
| Until you came in and became my tether.
| 
| You don\'t speak a word, my dear,
| I feel your words, loud and clear,
| Whatever happens, you don\'t fear,
| I am strong now, and the troubles I can bear,
| 
| As you sleep in peace, I\'ll touch you gently,
| I\'ll comb your hair to ease, all its knots feebly.
| Rest all you want; there is nothing so urgently,
| I have to take care of them all, well and attentively.
| 
| Even if you are far, my heart is close to you,
| When I hear your voice, my eyes search for you,
| In happiness and sadness, my heart is full of you,
| I dared to jump the skies, to be with you.
| 
| Once I was a storm chaser, running far and wide,
| Till one storm caught me and tossed me aside.
| Now I am a Stormbreaker, being a chaser\'s guide,
| My catcher in the rye, my soon to be the bride!
| 
| I ask the spring winds, for many beautiful days,
| As we celebrate our wedding, with bliss and gay.
| I ask for the winter winds, to keep the stars at bay,
| To keep the clouds grey, for us to cuddle that way.
