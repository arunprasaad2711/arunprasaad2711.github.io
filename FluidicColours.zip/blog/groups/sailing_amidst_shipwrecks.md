Sailing amidst Shipwrecks
=========================

| When your naive heart, sees the strong gale,
| Decides to take a voyage, and let the ship sail.
| But little did the heart see, what lied beyond the coast,
| Of the rough tides, and the brewing storms.
| 
| Shipwrecked often, I feel quite lost,
| Frozen by the waters, and scorched by the heat.
| Holding on to the embers, of hope at any cost,
| I silently pray for help, to overcome defeat.
| 
| Finding the inner strength is hard at this moment,
| I feel weak and frail, to even face a gentle breeze.
| The scars of the past, that kept you grounded,
| Now weighs too much, for you to stay afloat.
| 
| As I struggle to float, I\'m counting my blessings,
| Holding on tight, to the fast receding dreams.
| My hands are bloody, and parched as well,
| Being pushed to breathe, while underwater.
| 
| Amidst all the turbulence, despite all the pain,
| Amidst the icy cold, despite the blistering heat,
| I am fighting all I can, with every ounce of strength,
| Longing hard for the light, of that one guiding star.
| 
| How long can I keep up, such a fight I don\'t know,
| My naive heart still beats, for the joys of tomorrow.
| Sailing amidst shipwrecks, I am mending my heart,
| Stitching all the pieces, for a voyage once again.
