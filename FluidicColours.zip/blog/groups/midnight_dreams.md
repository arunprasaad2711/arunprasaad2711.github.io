Midnight Dreams
===============

| I am thankful,
| for that glance from your eyes,
| I am blessed,
| for our intertwined fingers,
| I pray,
| for this night to never end,
| I hear your heart,
| whenever our eyes meet,
| 
| In this blissful solitude,
| your presence fills my soul,
| I am in your arms; you are in mine,
| naked and shameless, in our little world,
| I am grateful,
| for the universe to unite us,
| I hope this is forever,
| the bond we have for each other.
