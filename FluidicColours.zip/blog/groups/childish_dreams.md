Childish Dreams
===============

| With one little leap,
| I want to touch the sky,
| As I caress the leaves,
| The plants should blossom,
| 
| With my smile, I\'ll win the world,
| Fly high and kiss the moon,
| My heart is heavy with desires,
| With no care for the future,
| 
| I closed my eyes lying on a chair,
| And I wake up in the morning on a bed,
| With a friendly fight, I win foes,
| With my charm, I mend broken hearts,
| 
| I change style like the clouds that float,
| But my heart remains pure and pristine,
| A strange innocence, hope, and love,
| I\'ll spread and share to the world around.
