Moonlight
=========

| One day, I looked at the mirror,
| Then found, a hair quite silver,
| Seemed yesterday; I started my journey,
| Years passed, and I gathered memories.
| 
| Behind me, I see many laurels,
| Many goals; that I won trying,
| Many defeats; that I lost trying,
| Many lessons; that tempered me well.
| 
| I\'m surprised, for the paths crossed,
| Never imagined, the place I\'m now,
| Did quit, on some ventures before,
| Yet persisting, on many ventures still.
| 
| I walked, past the cold streets,
| The darkness, that tried luring me,
| The burdens, that made me question,
| The doubts, that pulled me back.
| 
| I still, have doubts and burdens,
| But then, the fog is clearing,
| Through it, I see light streaks,
| The darkness is now slowly receding.
| 
| I struggled, to find myself clear,
| My heart did break into pieces,
| That\'s when, it fully opened up,
| And I found myself quite clear.
| 
| I was, once full of doubts,
| I still, have a long road,
| But slowly, I am finding strength,
| And surprised, to tackle it well.
| 
| The fog, that clouded my judgement,
| Became thin, and started to fade,
| Through it, I see light streaks,
| Out came, the moon to guide.
| 
| With time, it gave me peace,
| Quite detached, from what is around,
| Yet attached, to what I want,
| Still cheerful, but calm and composed.
| 
| Then I, realised in a moment,
| The moon, that shined all night,
| Did vanish, yet there was light,
| I realised, the moonlight in me.
| 
| Don\'t lose, the hope in yourself,
| This pain shall also pass soon,
| You strain, and break your muscles,
| You rise, with more stronger muscles.
| 
| You grow, at your own pace,
| You break, your heart many times,
| But still, mend your broken pieces,
| What is, a moon without craters?
