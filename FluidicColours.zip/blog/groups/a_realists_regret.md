A Realist's Nightmare
=====================

| Is this the dream life?
| You ponder all the time.
| Is this the reality?
| You want to see fantasy.
| 
| In life, you saw,
| All the tested paths.
| Yet when you sleep,
| You see many possibilities
| 
| Standing firm on the ground,
| Goals seem fulfilling,
| Looking at the clouds,
| You feel a bit empty.
| 
| Amidst all the distractions,
| Striving to find hope,
| Keeping the reality alive,
| Against time and space.
| 
| What if the ideas,
| You thought all your life,
| You were quite sceptical
| Is a possible reality?
| 
| A truth you refused to accept,
| All the time to keep you safe,
| When you're forced to admit,
| What are you, my realist?