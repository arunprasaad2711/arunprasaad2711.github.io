Iron Queen
==========

| She has grace, like a beautiful flower,
| A flower that blossoms, gracefully from a fire.
| A heart so strong, a lady iron born,
| Yet so gentle, and sweet to kindle.
| 
| She flows like a river, carving her path,
| Nurturing the lands, wherever she passes,
| Dare not obstruct, the way she follows,
| A stream can be forgiving a flood will not.
| 
| Your love for people is so vast and wide,
| Even when divided, it is abundant.
| Kind and caring and charming you are,
| When scorned your fury, is a treacherous storm.
| 
| Residing in your heart, a fire so bright,
| Brighter than the stars, I can see combined,
| A will so strong, forged from sun\'s core.
| You are a Queen, with the nerves of Steel.
