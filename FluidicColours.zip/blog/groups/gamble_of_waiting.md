Gamble of Waiting
=================

| It is in nature, to expect something,
| Very few venture, to gain nothing.
| Some events in life, are not so straight,
| You might have to, sit and wait.
| 
| Fortune favours the bold some say,
| Ask and wait it\'ll come some say.
| Stuck between, is the confused soul,
| Lost and clueless, aiming for the goal.
| 
| There is truth in both the cases,
| They do work out in many places.
| The struggle is real to find the best fit,
| When to move forward, and when to just sit.
| 
| Going with the flow, without any care,
| Many things will happen, and it may not be fair.
| Making up your mind, and seeking what you want,
| There is some hope, that you\'ll get what you want.
| 
| Unfortunate are those, who tried so hard,
| Failed many times, tired and charred.
| Although not a victor, they did try it out,
| They have closure and their hearts don\'t shout.
| 
| Miserable are those, who waited so long,
| And hoped that someday, they\'ll sing a song.
| They realised too late; the ships started sailing,
| That is a big regret, the gamble of waiting.
