In search of a Unicorn
======================

| Walking up and down the roads,
| Crossing many valleys and fjords,
| Ascending and descending many peaks,
| Walking steadily for many many weeks.
| 
| I smelt your scent, and tried to track you,
| Attempted many times, and I still missed you.
| In my quest to find where you are,
| I discovered myself the most so far.
| 
| On the way I saw, many nomads like me,
| Seated on horses firmly, who think they are free.
| They laughed at my naivety, and told me I'm foolish,
| But I moved forward, discarding their rubbish.
| 
| For they do not know, the thirst to discover,
| To break and fall apart, and still rise and recover.
| A few salted hairs do not imply wisdom,
| For wisdom doesn't come in exchange for freedom.
| 
| My quest maybe foolish, and all this may be a loss,
| At times of despair, this thought does cross.
| Is it sheer stubbornness or resolve I can't tell,
| Your magic is strong, and I'm bound by your spell.
| 
| And so I keep walking one step at a time,
| Penning songs on my way with a rhyme.
| Even if I fall, I'll rise and continue once again,
| I found you once, and I shall find you again!
