You have two legs
=================

| You searched all around the world,
| Amidst trials and many tribulations,
| It was not your fault to begin with,
| For you were told it comes from outside.
| 
| You were young, meek and timid,
| A dreamly and naive cinnamon roll,
| You thought the world will be like you,
| When the reality hit, your heart shattered.
| 
| With the rosy lens now shattered and gone,
| You see the true shades of black and white.
| Most people would have killed the child,
| Yet you are stubborn to save the child.
| 
| Amidst the critics, insults and injuries,
| You refuse to lay low and chose to climb back,
| It is when you realised that what you seek,
| Was within you for your child to find.
| 
| Can a broken jar hold any water?
| Can a broken heart hold any love?
| Unlike the jar that is broken when fallen,
| You can stitch your shattered pieces of heart.
| 
| You are stronger than what you see yourself,
| For a tree with fruits gets pelted the most.
| Ignore the morons who say you're not enough,
| For they think they are gods because of power.
| 
| You have the strength to rise again and again,
| Yet you must remember, you are still human.
| It is not a sign of weakness to accept who you are,
| It is a sign of strength to accept and move forward.
| 
| When stuck with a crisis and met with an impasse,
| It is human to feel pain and natural to grieve.
| So after you feel remember that you have two legs,
| Get up, stand, turn around and move forward.
