Storm Breaker
=============

| Shipwrecked in the past, haunted by memories,
| You doubted a lighthouse, which could set you free,
| A heart so naive that trusted blind,
| Now scarred and broken, scared and hurt,
| 
| A storm brewed within your heart,
| Winds of torments, and rains of tears,
| Like the waves of a sea, this too shall pass,
| The failures of the past, tell you who you are.
| 
| Be strong my dear one, and keep calm,
| Open your heart, and let the past go,
| Storms will come, and storms will go,
| And you\'ll emerge strong, and wise,
| 
| Face the storm head-on, my child,
| You are strong and brave and wild,
| When others flee a storm, you break one,
| Have faith and sail, my mighty storm breaker.
