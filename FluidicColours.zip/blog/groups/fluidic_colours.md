Fluidic Colours
===============

| When the cool winds caressed,
| When the waning moon blessed,
| The heart was full of colour,
| What it meant I wonder.
| 
| The colours came and went,
| What emotions they sent?
| For every thought, a colour emerged,
| Thinking about you, my thoughts converged.
| 
| Like the flowers that blossomed,
| Spreading all the fragrance around,
| My love for you blossomed,
| Gradually and without any bound.
| 
| Do we have a bond?
| Then why do I hear your heart?
| As if bound by a wand,
| I remember your words by heart.
| 
| Like the birds that sing sweet,
| As sweet as honey a lovely treat,
| I have a song for you quite upbeat,
| True and sincere and hard to retreat.
| 
| Sweet as nectar my heart feels joy,
| On hearing your words, rejoiced this boy,
| Our talks and words made no sense,
| Yet we can\'t stop hearing this sweet nonsense.
| 
| Like the leaf on a flowing stream,
| The world is changing its scheme,
| Amidst many aspirations and dreams,
| Time is fleeting and changing its theme.
| 
| What time holds in our future?
| Regardless I shall always nurture,
| The memories and moments with you persistent,
| Change is not my only constant.
| 
| Like the morning dew that rejuvenates,
| Thinking of your love my heart scintillates,
| In a mystical trance, it eternally oscillates,
| Meanings of life it quietly resonates.
| 
| All the sparrows and their flock,
| Will come together and sing our song.
| All the parrots and their flock,
| Will come along and write our story long.
| 
| I thank the universe for letting our lives cross,
| Knitting our lives with moments like a floss,
| I don\'t believe in any god or any faith,
| But for you, I am ready to leap with faith.
| 
| Traversing life riddle after riddle,
| I don\'t know how it will unfold,
| With you beside me, it will be gentle,
| Together we shall pen a story never told.
