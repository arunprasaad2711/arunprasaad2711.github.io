Nemesis Reborn
==============

| You thought you won when you broke me that day,
| That dance of arrogance, I still remember,
| My heart did swell, and bled with a vengeance,
| Anger did boil, and flowed through my veins,
| 
| While you danced and rejoiced, I stood up once more,
| With hands of diamonds, and nerves of steel,
| Gone are the days, I played for sport,
| Now I am ruthless, with a spine-chilling smile,
| 
| When we meet to fight, you will tremble in fear,
| All the sins of your life will flash in front of your eyes,
| Flee if you want, it won\'t matter,
| For I will find you, and I will kill you,
| 
| Say your prayers, and count your blessings,
| For the monster you are, you deserve no pity,
| You saw me fall, now see me rise,
| Run far away; your nemesis is reborn.
