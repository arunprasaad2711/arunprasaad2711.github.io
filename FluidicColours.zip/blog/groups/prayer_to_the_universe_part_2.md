Prayer to the Universe - Part 2
===============================

| With all of humility , and full of pain,
| I call upon you to hear me explain,
| For you, the head of all our clan,
| Please listen gently, and make a plan,
| 
| With, the world going mad,
| Millions, are very sad,
| The weather, is very bad,
| And no one, is truly glad,
| 
| So many wars, and so many fights,
| Thousands are helpless, to see these sights,
| The days are fading, with peaceless nights,
| People are running, to escape many plights,
| 
| Thousands are dying, with numerous disease,
| Is there a way? To cleanse this unease?
| Wars of Faith, failing to cease,
| I am powerless, as if decease,
| 
| Lighting a lamp, is a plain crime,
| While thousand crimes, do rhyme,
| This \"world\" of humans, has lost it\'s prime,
| Corrupting everyday, as if there is time,
| 
| Children are crying, People are lying,
| Many are stealing, Many are killing,
| None are changing, Morals are falling,
| When the good are tying, no one is buying,
| 
| I am powerless, bounded by chains,
| Becoming hopeless, with unheard claims,
| Struggling to be fearless, despite heavy rains,
| Soon will be tearless, with watery plains,
| 
| Change this world, With women standing equals,
| Change this world, With faith preaching morals,
| Change this world, With children having meals,
| Change this world, With people joining realms,
| 
| With tearful eyes and burdened heart,
| Finding it hard, to move in my cart,
| Hoping to see a day, with a hopeful heart,
| When all of these are truthfully sort!
| 
| \"I want revolution! Nothing else shall suffice!\"
| \"Please bring evolution! This species can\'t previse!\"
| \"World is an involution! With no cure to advice!\"
| \"It needs annihilation! This is the revise!\"
