Little Joys
===========

| As the days go by, I latch to your memories,
| Lingering like fragrance, from an emptied perfume,
| I know deep down; I will meet you soon,
| But the wait is painful, without you nearby.
| 
| The endless reveries, that pulls me out from life,
| An overlooked feeling, that adds hope to life,
| Adding purpose and solace, and a bit of wine,
| To my famished heart, amidst the daily strife.
| 
| I am very thankful, for all the wonders in the world,
| For trying very hard, to distract my mind from you.
| Although they succeed, for a brief moment,
| What is a raindrop, in front of an ocean?
| 
| The friendly little bickering, fights and silly games,
| The moments of togetherness, through thick and thin,
| When I was young, I felt I was cursed,
| Now I reflect, and I realise I’m blessed.
| 
| A good friend, a guide and my anchor,
| Who saw me through and knows me more.
| As I wait so patiently, for my ship to reach the shore,
| I linger to all our memories, with a dorky smile.
| 
| I wish we could be kids still, without worry about life,
| And eat mangoes in the day, and watch the stars at night.
| Yet I am glad for all the moments we spent,
| For those precious memories, are my little joys.
