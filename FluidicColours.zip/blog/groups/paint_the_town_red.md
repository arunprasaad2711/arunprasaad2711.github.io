Paint the town Red
==================

| It was raining blue, the dye of the sky poured,
| In the quiet that followed, I heard your heartbeat,
| A naughty smile lingered, in the corner of your lips,
| A twinkle of mischief, and spark in your eyes,
| 
| In the evening twilight, I saw a sun rising,
| I turned to see it, and I saw you,
| In the weariness of the evening, I had a dream,
| It was about you, and you came in front of me,
| 
| I want to hold your hand, and walk on the beach,
| See the beautiful sunset, as you lean on me,
| The winds caress my hair, and kissed my cheek,
| I turned to see you, and our eyes met,
| 
| As we talked and chatted, the birds did chirp,
| It told me to come near, and told me to hold you,
| We didn\'t speak a word, but our hearts talked a lot,
| With a bit of mischief, we ran to paint the town red.
