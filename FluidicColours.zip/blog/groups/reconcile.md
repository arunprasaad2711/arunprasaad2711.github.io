Reconcile
=========

| Between right and wrong, being stuck so long,
| When two poles meet, with no room for defeat,
| Amidst truth and lies, hiding in disguise,
| There is some wisdom, without conundrum.
| 
| The angel is in peace, with divine expertise,
| The devil is content, with ignorant intent,
| Fighting all desire, like ice and fire,
| Lost is the mortal, trying to be an immortal.
| 
| Two roads once met, and regret filled me,
| I chose the road levelled, for the road less travelled,
| And I made my peace, healthy and in one piece,
| Problems never cease, but I decided to find peace.
| 
| When you travel a while, it is hard to reconcile,
| Life is not stark, like light and dark.
| It is natural to stray; we are genuinely grey.
| Make peace with the wrong; life is not that long.
