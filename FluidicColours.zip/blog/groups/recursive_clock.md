Recursive Clock
===============

| The moment I got you, I never went back,
| Turning your dials, time became simple.
| As your hands moved, she began to sway,
| The unseen enchantress became my lover forever.
| 
| Is this magic? Or is this a wonder?
| I visited my past self, ahead in the future.
| Saved my younger self, from taking a wrong turn,
| I lived a hundred years, in a fraction of a second.
| 
| Am I blessed to have you? Or cursed to possess you?
| The power you hold is quite unfathomable.
| For once in my life, I feel like God!
| I can undo my wrongs, and rewrite the world!
| 
| Time became my lover, and I became a nomad!
| Travelling to and fro, between the past and future.
| I dropped the infamous apple that made Newton blink!
| Gave the thought to Einstein, and made the world think!
