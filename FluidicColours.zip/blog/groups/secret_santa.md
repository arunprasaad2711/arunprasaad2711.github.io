Secret Santa
============

| The days grew short,
| The winds blew cold.
| But that can\'t twart,
| The festival quite old!
| 
| Patience is quite needed,
| Now it\'s top seeded.
| For I have to wait,
| And not fall to bait.
| 
| I wished for a gift,
| Time was slow to drift,
| As I waited all alone,
| Cold to the bone.
| 
| All of a sudden,
| I found a gift hidden,
| Better than what I asked,
| A book of poems unasked!
| 
| Who are you, Santa?
| I\'m smiling in joy.
| Where are you, Santa?
| I\'m jumping like a boy!
| 
| Thank you quite truly,
| For the gift so duly.
| Love you with all my heart,
| My happiness is off the chart!
