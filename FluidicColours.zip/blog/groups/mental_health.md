Mental Health
=============

| When you feel low, and time flows slow,
| The world moves fast, and you feel you\'re last,
| Trying to evade the pain, you wander in vain,
| Buried in your thought, you feel lost.
| 
| You hear voices, deciding your choices,
| Hold on to your braces; these are just noises.
| When your fear summons, the inner demons,
| It is okay to yelp we are there to help.
| 
| The mind is very fickle, and problems do trickle,
| Better act quick, before you get sick,
| Mental illness is not subtle, and needs no rebuttal,
| What can you truly gain, by suppressing all the pain?
| 
| Such illness is uncommon, but naysayers are common,
| But don\'t let the outrage, drain down your courage.
| You are not insane, and those who say so are a bane!
| Tend to your brain that is in pain!
