Curse of being strong
=====================

| There were times you were left all alone,
| Helpless and lost, with a heart of stone.
| All you wanted, was a candle in the dark,
| All you got, was indifference quite stark.
| 
| You pulled your socks up, and went for battle,
| Amidst all the voices, that tend to belittle.
| Burning the midnight oil, you continued to persist,
| Steadily and surely, you went through the mist.
| 
| Now you got through, what was once quite rough,
| Now others look at you as if you\'re quite tough.
| They all praise and sing, how strong you are,
| Unaware of the journey, and the perils so far.
| 
| Now you are a beacon, for their hopes and dreams,
| Their whole life depends on you; they do scream!
| Asking you the gist, of your journey with disregard,
| Wanting the rosy road, instead of the road so hard.
| 
| Treading the hard road, you became so strong,
| Learnt to find the truth, amidst all that is wrong.
| When you needed help, you got indifference,
| Now you asking help makes no difference.
| 
| The curse of being strong is that you\'re left alone,
| To fight and fend your battles, all on your own.
| Very few shall relate, to the trials you went through,
| For you chose to move on, and see events through.
