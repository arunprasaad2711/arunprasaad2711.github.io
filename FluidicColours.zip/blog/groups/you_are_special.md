You are Special
===============

| None can imagine, what you went through,
| There might be days; you wanted to end it all,
| I am sorry, I didn\'t comprehend,
| The suffering and pain, the tears and scars.
| 
| You never thought, the tragedies of life,
| A cruel joke, to be a victim of it.
| Enough of the days, you hid behind a smile,
| You deserve more, and this is not the end.
| 
| A thousand doors might close, but never fear,
| If you end it all, you won\'t see it through.
| You have a gift, a precious life,
| No sorrow in the world is worth its price.
| 
| You are unique, In this ever-changing world,
| Hold my hand; you are not alone.
| It is excruciating, but be firm,
| Your winter will leave, and spring will come!
