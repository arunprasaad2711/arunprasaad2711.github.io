Indra
=====

| I defeated sleep with a fight,
| And stayed awake all night,
| To see the moon wane,
| After it waxed once again.
| 
| While the eyes admired the moon,
| The heart hoped to see you soon,
| Through the moon's many phases,
| I saw your heart's many faces.
| 
| Lying on the grass amidst the dew,
| A breeze caressed me as it blew.
| I turned around to see you linger,
| Behind the tree, my smile bringer.
| 
| In my dreams I see you smile,
| You peck my cheek once in a while,
| My little heart always skipped a beat,
| When you're close to me to greet.
| 
| You came to my life when I started to wax,
| My life before you was never truly lax.
| Even now it is a tough fight,
| With you beside me, my heart feels right.
| 
| My dreams about you are quite rife,
| I hope I see you soon in real life.
| Like the land and the sky forever,
| We'll be together forever and ever.
