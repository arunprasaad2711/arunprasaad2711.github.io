Being Brave
===========

| In the tides of life,
| It was easier to conform.
| But the more I did,
| I started losing my soul,
| 
| When your calling is genuine,
| And your purpose adds joy to the cosmos,
| Why should you settle for the plain,
| When you can reach for the summit?
| 
| Even when the one you seek is lost,
| There is valour in trying, and it is endearing.
| A closure that you gave your heart,
| Instead of admitting failure by default.
| 
| You\'re the child of a star, born to shine,
| Go higher and higher till your heart\'s content,
| When the whole wide world is your Oyster,
| Why should you settle for the dust?
