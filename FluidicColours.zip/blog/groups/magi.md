Magi
====

| Someone knocked on my door,
| And brought me back to the world.
| "What is it you seek?", I asked.
| "None, what do you seek?", they asked back.
| 
| "Why did you come?", I never called them.
| "Your heart is in agony.", they told me.
| Baffled and confused, I let them in,
| They brought gifts, queer and rare.
| 
| "I seek many, and I feel lost", I told,
| "Seek what is certain, you will be fine.", they told.
| "I try hard, and yet I don\'t grow", I told.
| "Do you rest in between and heal?", they asked.
| 
| "Whatever I learn, it is incomplete", I told.
| "Be an open bowl, and remove the lens", they told.
| "I keep trying, and somethings never happen", I told.
| "Keep trying and grow, things will happen", they told.
| 
| "No one understands me, I try to", I told.
| "Know yourself, and others will follow", they told.
| "I aim too high, and fall too low", I told.
| "You are mature but naive, go steady", they told.
| 
| "I feel I am inadequate, and I am hard", I told.
| "Realise you can find what you want", they told.
| "Will I be happy? Will this happiness last?", I asked.
| "It will last", they told, "as long as your heart is free."
