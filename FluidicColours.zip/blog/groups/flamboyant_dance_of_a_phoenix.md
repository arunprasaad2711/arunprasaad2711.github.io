Flamboyant Dance of a Phoenix
=============================

| Among the group there stood one,
| Unnoticed by the common ones,
| Who wanders around wide and far,
| Curious and kind, her nature by far,
| 
| Full of hope and full of care,
| With a heart overflowing to dare,
| While people walk away with others,
| She spreads awe in a dance of colours,
| 
| While I walked in a colourless planet,
| Minding my work and winding my life,
| She flashed into my life as a sonnet,
| And changed my life with the dance,
| 
| With her wings of majestic beauty,
| With feathers of red, green and blue,
| She made the calm sky brightly sunny,
| And none on this world didn't have a clue,
| 
| Who is she? The lovely little damsel?
| Whose mere existence is refining my conscience?
| She makes all the worldly knots unravel,
| Breaking the boundaries put by science,
| 
| With her majestic wings and peculiar smile,
| She basked in the sunshine hovering for a while,
| As she hovered she dived into a cloud,
| And out came a thunderous storm,
| 
| The storm rained black and blue,
| Its rain cleansed my sins and woe,
| It restored my world to the way it was,
| Free from all forms of worry and foe,
| 
| Unaware to all the Phoenix had fears,
| That nobody shall see her tears,
| Tears that flow on seeing people hurt,
| She wanted to cleanse the people of dirt,
| 
| The storm that brewed was not of the clouds,
| But the rage and pain that brewed in her soul,
| With her charm, she fooled us with the clouds,
| And her tears were the rain that fell to heal,
| 
| The sun rises and sets every day,
| But it was dark even today,
| The dance she offered today,
| Was something to be hailed every day!
| 
| Out came a gust that swept the world,
| That filled our hearts with bliss,
| It was the songs of the lovely damsel,
| That echoed all around the world,
| 
| Her voice echoed into everyone\'s heart,
| Reaching the unreached and heard by all,
| It travelled even the deepest of voids,
| The cruellest of hearts and through strongest of barriers,
| 
| We all have rules and principles,
| Even a religion to show our face,
| Simple or profound all have one,
| All designed to keep us safe,
| 
| But when she danced, there was a tremor,
| An unnatural sense that words failed to name,
| It was the waves of shock and surprise,
| That my whole life longed to see,
| 
| I felt the rules get broken,
| I sensed my freedom multiply,
| It gave me the courage to dare,
| The power to question my faith,
| 
| My inhibition tend to fade,
| My heart filled with hope,
| I dared to leap,
| That I feared all my life,
| 
| I broke the false shackles of society,
| Realised the bounds that surround me,
| From a frog confined to a well,
| I became a phoenix, wild and unbounded,
| 
| That dance struck my heart with a cure,
| And guided me to greater heights and more,
| That dance was not a dance, but a fight,
| A fight for the meaning of existence,
| 
| Nor was I the only mortal to feel,
| But there were many who went with the wind,
| All felt similar remorse at heart,
| And did the impossible defined by immortals,
| 
| But that was not the end to the dance,
| The dance was rather a choice and chance,
| All of a sudden, when all were there to stare,
| The damsel stopped and vanished in thin air,
| 
| The lovely Phoenix that filled the sky with delight,
| Blew into flames and went out of sight,
| Filled the sky with a spectacular light and flare,
| Sweeping darkness like a second sun in the sky,
| 
| Out came the feathers all lit with flames,
| Turned into ashes as they touched the grounds,
| Ashes untouched filled the lands with meadows,
| And among the blades of grass stood a baby bird,
| 
| Among the fortunate who took the ashes,
| Their hearts were filled with fire,
| A fire that taught passion and compassion,
| A fire for meaning, a fire for existence,
| 
| For the sceptical mortals who chose to avoid,
| Life was still colourless and void,
| For the strugglers and believers who chose to see,
| Life always went flamboyant and sane,
| 
| The strugglers and believers who realised the dance,
| Who knew it was a choice and chance,
| Stood like a lighthouse strong against the waves,
| And guided many ships amidst turbulent oceans,
| 
| When coerced, forced, humiliated or betrayed,
| Even when the entire world stood against my will,
| I stood strong like a king and fought, when,
| The damsel appeared and saved my skull,
| 
| Whenever in solitude, alone or in grief,
| I remember the dance that lovely damsel gave,
| It filled my heart with ecstasy and belief,
| That happily haunted me till my grave,
| 
| The dance of the damsel was a message to all,
| What everyone can do! In the form of a phoenix!
| Those who seek true glory do in front of all,
| The Flamboyant Dance of the Phoenix!
