Excelsior!
==========

| A dreamer I am, I loved fantasy,
| For in its core, there is ecstasy,
| Many people say some dreams are impossible,
| Till, a soul like you, comes and makes it possible.
| 
| Your art made me wonder, and warmed my heart,
| Many stories to ponder, with characters off the chart!
| You lived a life rich, and full of memories,
| Making my childhood sweet, with your great stories.
| 
| Who shall be worthy of filling your place?
| Thor can never find, a worthy one to replace!
| When Peter met Mary Jane, his heart skipped a beat,
| Will there be someone, to fill your seat?
| 
| The legacy you leave is insurmountable,
| The brilliance you showed, is unmeasurable!
| Till my heart beats, I shall always remember!
| The role you had in life, for aeons together!
