A Farewell Song
===============

| You came here long back,
| And helped us all grow.
| Are we ready to fill your shoes?
| Although grown, we don\'t know!
| 
| We\'ll miss your soft voice,
| The calm presence most of all.
| A dance of grace and brains,
| Filled with abundant maturity.
| 
| Though we are young, we will remember,
| The lessons you taught us forever.
| We will miss you, with all our heart,
| Although we smile, our hearts feel a void.
| 
| Your ship has come, for you to sail,
| A new chapter begins, in your new voyage.
| We wish you all the best, for your journey ahead!
| This is just comma; our lives will meet again!