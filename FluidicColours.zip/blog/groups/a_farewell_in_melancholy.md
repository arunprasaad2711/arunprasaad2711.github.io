A Farewell in Melancholy
========================

| As the night gathers, I compose for this special day,
| A day to reminisce, a day to cherish.
| Had I not chosen this path, where would I be this day?
| Would I be in this place? Or would I perish?
| 
| With a heavy heart, amidst joy and sadness,
| I look back, with less-tinted glasses.
| I lingered on, to every fleeting moment,
| Wished to capture, every little movement.
| 
| The days of happiness, the nights of liveliness.
| The days of sadness, the nights of loneliness.
| All the nocturnal musings, journeys and memories,
| The never-ending vagaries of the world and reveries.
| 
| The wild heart, beaming with love.
| The broken heart, plunging into sadness.
| The prideful heart, glowing with hope.
| The fallen heart, spiralling into madness.
| 
| Had I not chosen this path, where would I be this day?
| I\'ll never know, but I am proud I did!.
| Would I be in this place? Or would I perish?
| I\'ll never know, but I am proud I did!.
| 
| As I sit here, I pray to the Universe,
| For a life of happiness, etched as a verse.
| With longer summers and shorter winters,
| Painted in the colours of Autumn and Spring.
