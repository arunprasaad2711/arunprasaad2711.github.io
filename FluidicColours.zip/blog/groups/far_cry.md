Far Cry
=======

| When he was all well,
| He felt dead on the inside,
| For the world was stale,
| And content became contempt.
| 
| When he was never well,
| He felt lively on the inside,
| For the world was changing,
| And no room for content.
| 
| When things went well,
| He asked for a challenge,
| He wanted to feel his blood,
| Rushing through his veins.
| 
| When nothing went well,
| He asked for peace,
| He felt all the thoughts,
| Rushing though his mind.
| 
| A man is such, a living irony,
| Asking for things, he can't have,
| Rejecting the things, he does have,
| Cribbing about both, again and again.
| 
| Through happiness and suffering,
| He thinks he defies nature,
| But all he does in actions,
| Is a vain attempt to be a far cry.
