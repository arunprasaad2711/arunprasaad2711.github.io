Wandering Soul
==============

| Between right and wrong,
| Between madness and valour,
| Between past and future,
| A field of grey,
| A surreal feeling,
| A present moment,
| 
| A singular moment,
| Where I wish time froze still,
| A conflicted feeling,
| Where I wish to cry and smile,
| A blurry field,
| Where I hope I am right,
| 
| Like the still waters of a deep lake,
| The moon uses to admire its form,
| Keep calm, and be hopeful,
| Wherever I am, I\'ll find my way to you,
| For I am a sailor, aboard on a voyage,
| And you, my beloved, are my pole star,
| 
| Like the bees that visit flowers,
| I wander in search of a treasure,
| Despite visiting many blossoms,
| The bee knows its way to its hive,
| Wherever I may go or be,
| My heart will beat your name,
| 
| In times when I was lost, broken or hopeless,
| Drifting aimlessly on the tides of life,
| Even when the moon refused to show itself,
| I saw you twinkling on my night sky,
| Guiding me to the nearest shore,
| And you filled my heart with hope,
| 
| I am a wanderer, venturing into the unknown,
| Filled with fear and valour in equal measure,
| But the bond I have with you,
| Is stronger than the mountain and land,
| Despite the uncertainty, one thing is clear,
| Because of you, a wanderer like me is never truly lost,
