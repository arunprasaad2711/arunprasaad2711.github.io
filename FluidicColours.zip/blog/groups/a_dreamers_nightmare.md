A Dreamer's Nightmare
=====================

| Is this the real life?
| You wonder all the time.
| Is this a fantasy?
| You want to see reality.
| 
| In dreams, you saw,
| All the endless possibilities.
| Yet when you wake up,
| You see the ending realities.
| 
| Floating over clouds,
| All seems perfect,
| Waking up to reality,
| The dreams dissolve.
| 
| Amidst all the distractions,
| Striving to find hope,
| Keeping the fantasies alive,
| Against time and space.
| 
| What if that idea,
| You chased all your life,
| You hope to make it real,
| Is a mere fantasy?
| 
| A lie you tell to yourself,
| All the time to keep you safe,
| When that is take away,
| What are you, my dreamer?