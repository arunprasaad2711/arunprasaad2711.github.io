Imperfectly Perfect
===================

| You take great care,
| And factor every detail,
| To do it perfectly,
| And everyone applauds you.
| 
| But you are human,
| Bound to make errors.
| And when you slip,
| Others can\'t accept it.
| 
| When you\'re aiming perfection,
| You go great lengths,
| You take great pains,
| To make moments right.
| 
| What is the price?
| Your pay in return,
| Only you know it,
| Others can\'t see it.
| 
| You push the bar,
| To a new summit,
| Unknowingly you keep adding,
| More pressure to yourself.
| 
| The journey of perfection,
| Often blinds your vision,
| To the self-inflicted harm,
| And the agonising loneliness.
| 
| It makes you mad,
| To see flawed people,
| Doing work just fine,
| Cheerful, laughing and happy.
| 
| While you plough through,
| So many intricate issues,
| That others couldn\'t see,
| And you take responsibility.
| 
| Remind your gentle heart,
| That there\'s nothing wrong,
| For the losses incurred,
| Were aims too high.
| 
| The peril of perfection,
| Constricts your breath away.
| Makes you be hard,
| On yourself all time.
| 
| While it is good,
| To be hard once,
| But when done often,
| You shatter your peace.
| 
| It throws you ultimatums,
| And makes you paralysed,
| While trying to make,
| Decisions all the time.
| 
| Can you pen tales,
| With dry, empty pens?
| With worn out nibs,
| And leaking body parts?
| 
| You, my dear perfectionist,
| The price you pay,
| For being very hard,
| Is to break yourself.
| 
| Like the broken pen,
| That leaks all ink,
| Your sad broken heart,
| Will leak all happiness.
| 
| And just like how,
| You seal the cracks,
| To stop the leaking,
| Your heart needs fixing.
| 
| When a pen breaks,
| You can buy another.
| When your heart breaks,
| Can you replace it?
| 
| The journey of perfection,
| Does shackle your limbs,
| To break all shackles,
| Start loving yourself more.
| 
| You are not satisfied,
| Not because of arrogance,
| It\'s that you developed,
| A knack for things.
| 
| True perfection occurs when,
| Not when under control.
| Rather you let go,
| Of worries and play.
| 
| While perfection is noble,
| And everyone appreciates it,
| Others become detached to
| What you truly are.
| 
| To strike a bond,
| With the people close,
| Perfection does not matter,
| It is the flaws.
| 
| Despite what you do,
| You are a human,
| Bound to make errors,
| Bound to learn again.
| 
| While it is wise,
| To have watchful eyes,
| You should understand dear,
| It is quite natural.
| 
| This is a lesson,
| To keep in mind,
| When you plough through,
| And hurt yourself badly.
| 
| This is a lesson,
| To forget in mind,
| When you make mistakes,
| And you don\'t learn.
| 
| When you love yourself,
| You accept yourself wholly,
| The good parts and,
| The broken parts too.
| 
| A sense of peace,
| Does linger in you,
| When you accept yourself,
| And it radiates outward.
| 
| You now truly become,
| The pen you dreamt,
| To write many tales,
| To your heart\'s content.
| 
| This is what truly,
| Means to be yourself,
| Your heart and mind,
| And body in unison.
| 
| When this does happen,
| Your heart is full,
| Of happiness and joy,
| And a serene calmness.
| 
| In such restful state,
| The heart is content,
| The mind is clear,
| Your body is ready.
| 
| Now you set forth,
| Your journey of perfection,
| You will sail smooth,
| And you will win.
| 
| In such restful state,
| Your union is complete,
| And you find ways,
| To correct all flaws.
| 
| Now people will not,
| Think of you odd,
| For they have seen,
| Your best and worst.
| 
| And now more importantly,
| They saw your flaws,
| And were able to,
| Relate with you truly.
| 
| Added to your admiration,
| They shall feel related,
| The formal talks dissolve,
| And the controls fade.
| 
| They now feel calm,
| To open themselves up,
| For they see you,
| As a human too.
| 
| None of us are,
| Truly Gods in life.
| We may climb up,
| But still are humans.
| 
| If we are perfect,
| Will we be humans?
| That begs the answer,
| Imperfections make us human.
