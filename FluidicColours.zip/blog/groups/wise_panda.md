Wise Panda
==========

| Once you were quiet and shy,
| For reasons don\'t know why.
| After you freely opened up,
| It\'s difficult to shut you up.
| 
| With an eye to capture colours,
| Your photos are true wonders.
| You observe every detail,
| And nuances without fail.
| 
| Chirpy and lively as an extrovert,
| But deep down a big introvert.
| Fierce and crazy full of charm
| Kind and caring and warm.
| 
| While some are a symphony,
| You genuinely are a rhapsody.
| Hard to say if you\'re ice or fire,
| But you are a friend to desire.
| 
| You observe all the people around,
| Your wisdom is quite truly profound.
| Your heart is finite, yet
| Your love for friends is infinite.
| 
| Talking with you is such ease,
| Fun and lively with a bit of tease.
| After your arrival life is colourful,
| This is the start of something beautiful.
