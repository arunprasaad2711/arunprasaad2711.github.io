Concede
=======

| You\'re running all day, in the pursuit of success,
| You march ahead strong, without any digress,
| You\'re certain you\'ll win, for you it\'s obvious,
| While there are many factors, totally oblivious.
| 
| When ideas become real, your faith gets checked,
| You either set sail or get beaten and Shipwrecked!
| When the journey goes smooth, you sing a song,
| When the tides go rough, you think what went wrong!
| 
| It is quite tragic when the winter winds blow,
| For no fault of yours, life gets cold and slow.
| It is quite splintering, when you make mistakes,
| For all the fault is yours, you lose all the stakes.
| 
| Your strength is invisible when you have everything,
| It is seen quite well when you can\'t get anything!
| It is not in arrogance, that refuses shamefully,
| It is in humility, to concede gracefully.
| 
| It is human to error, and we all are imperfect,
| It is a fallacy to believe, that you are quite perfect!
| It takes courage to be strong, and pursue a goal,
| And much much more, to mend your shattered soul.
| 
| It takes strength to concede, and change your way,
| Muster all the courage and redefine your say.
| Having tasted defeat, you\'re not scared to play,
| Or change your game, while travelling midway!
