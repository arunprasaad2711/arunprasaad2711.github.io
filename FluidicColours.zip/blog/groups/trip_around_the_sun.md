Trip around the Sun
===================

| In my heart resides, a million dreams,
| Of travels and memories, of life and laughter,
| On this very day, as I wander and ponder,
| I seek your blessings, as I turn around again,
| 
| I was born a human, with a spirit of a bird,
| I wish to fly high, and touch the milky clouds,
| To sail against the wind, amidst turbulent times,
| I seek your good wishes, as I turn around again,
| 
| On this day I think, of old times and days,
| My throat does stiffen, and a sad smile lingers,
| With all these people around, I feel you missing
| I seek your divine presence, as I turn around again,
| 
| I must move on; I have promises to keep,
| I linger for a moment, to capture your grace,
| A new year for me, I want you to be there,
| Around the Sun I go, as I turn around again!
