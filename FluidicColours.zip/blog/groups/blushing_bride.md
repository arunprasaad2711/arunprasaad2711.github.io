Blushing Bride
==============

| As the day nears, my heart overflows with joy,
| My eyes express shyness, my lips speak my happiness,
| This was a day I dreamt, right from a tender age,
| I am glad it is happening, a day of new beginnings,
| 
| My little heart is restless, swinging between joys and dreams,
| Even when I am afar, my eyes keep looking at you,
| I savour your charm, from the corner of my eyes,
| And reciprocate the love, you always showed on me,
| 
| When I am alone, my heart yearns your touch,
| Your gentle caress strokes my inner soul,
| When we dance, the moon turns pink,
| The birds will forever sing, our love for aeons,
| 
| When the darkness prevails, our story shall begin,
| Help me pen a tale; even the angels can't recite,
| Recite your vows; I am ready with mine,
| Let's hold our hands, as husband and wife.
