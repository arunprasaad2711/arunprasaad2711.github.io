Nameday
=======

| The beautiful moon in the sky,
| All of a sudden became shy,
| Watching it, I wondered why,
| 
| Wandering the sky all around,
| It stood still to hear the sound,
| Of a song so profound,
| 
| Lines that rhyme sweet and fine,
| With grace and elegance so divine,
| Sang the boy of age twenty-five.
| 
| The twinkling stars made the ambience bliss,
| The beauty of his song quite hard to miss,
| The lively voice was such bliss,
| 
| The clouds gathered to see him sing,
| As happy subjects meeting a king,
| With a truant thunder giving a timely ring,
| 
| The rain showered, like the tears of joy,
| To praise the talent of this beautiful boy,
| Me the witness could only enjoy,
| 
| The stars twinkled and wished him hope,
| Blessing him, a life with a rising slope,
| And strength to pass barriers with a lope,
| 
| The shy moon beamed a bright glow,
| And danced in ecstasy, a beautiful show,
| I wished the time would move slow,
| 
| Many more happy returns of the day,
| A life full with sun's ray,
| Beyond that, what can I say?
