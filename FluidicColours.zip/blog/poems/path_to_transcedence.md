Path to Transcedence
====================

| As I float on the river, I got carried away,
| Drifting with the ripples, on a bright day.
| In the eerie silence, away from the worldly noises,
| All the noises in my head lost all their voices.
| 
| The voices I hear from the world were queer,
| They forced upon me and gave me quite a steer.
| Were the guiding me? Or were they bettering me?
| I couldn't tell truly, but they tried to alter me.
| 
| These voices that were quite resilient,
| The moment I dip my head went silent.
| All this time when I drowned myself into the world,
| These voices tried to keep me unfurled.
| 
| Voices that whined, that I'm not good enough,
| Voices that ridiculed, that I'm not tough enough.
| Voices that cried, about the mistakes of the past,
| Voices that brooded, about things that never last.
| 
| When I raised my head, again from the waters,
| The voices came back, emerging from the tatters.
| But now it was different, for now, I had the leash,
| And I can tie them down, or I can freely unleash.
| 
| Is it because I am floating, and drifting astray?
| Or because I gasped, as I lost my breath away?
| Is it because I chose, to turn back and walk away?
| Or because for once, I chose to rebel anyway?
| 
| As I float on the river, drifting like a wood,
| For once the ever running time froze and stood.
| The river's ripples settled my muddled thoughts,
| It gently caressed and undid my emotional knots.
| 
| The bubble that kept me, safe all along popped,
| The tints of colours it painted, the world dropped.
| For long I believed, the bubble to keep me safe,
| Now it's no more, and yet I am quite safe.
