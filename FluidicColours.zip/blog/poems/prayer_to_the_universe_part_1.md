Prayer to the Universe - Part 1
===============================

| I address you because you are absolute,
| And I believe that you are godly,
| And so with all the will and faith,
| I am asking you a lot gently listen.
| 
| Thank you for your valuable lessons,
| For teaching us various facets of life,
| Thank you for your joys and pleasures,
| Its a sign for our hopes being alive.
| 
| Let the air fill with hope and spirit,
| Millions and Millions are in desperate need,
| Reflect back all the wishes and prayers,
| For those who are worthy and deserving.
| 
| Let science and literature expand more,
| Let people know more about you,
| Let people touch your string that connect,
| Each and everyone and form a theory.
| 
| When times are dark, and hopes are faint,
| When good is rare, and faith is shaking,
| Give people the strength to sail the storms,
| Give them the courage to remain strong.
| 
| Let poverty vanish from the world,
| Let the hungry children get a good meal,
| Give every being a happy family,
| Make this world a better place to live.
| 
| Please make man to realise his errors,
| And all the blunders and faults he has caused,
| Let him realise from this moment,
| That he has to change and get remorse.
| 
| Let the corruption to this beautiful planet,
| Fade one by one till its fine once again,
| Let every new soul born in this world,
| Let it feel that this planet is a haven.
| 
| Let the sky fill with flamboyant birds,
| Let the world reach the ultimate limits of happiness,
| Let all the suffering, corruption, and all things bad,
| Let all of these feel that they have no bond with this world.
| 
| Let each family have heaven within,
| Let there be events to rejuvenate the happiness,
| Does a butterfly need a license to fly?
| Let the same be for the living and love.
| 
| If all of this is hard to make soon,
| Let it happen in its own pace,
| But let it happen in a pace such that,
| It keeps faith strong and always hopes up.
| 
| If some of these are to be done by us,
| Throw out signs, and please let us know,
| Lend us the magic to set things right,
| And bless us with your immaculate grace,
| 
| Shower your rays of joy to all living souls,
| Help them realise their roles in this cosmic existence,
|, Unlike the birds that take shelter during rains,
| Help us find the eagle in us to bask in the sunlight above the nimbus.
