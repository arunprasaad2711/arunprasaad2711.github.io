Nymphadora
==========

| Swaras, being 7 and finite,
| Can express the ragas infinite,
| But even the swaras failed with chords,
| To confess my endless love for you,
| 
| With the ragas, I know and the words I learnt,
| I attempted to pen for you, my dear saki,
| A letter of love, with lyrics of the divine,
| A song fit for the Gods combined,
| 
| My heart is full of words, about you,
| And songs full of thoughts, with you,
| My mortal heart, could not contain,
| Hence I send you, my musings of joy,
| 
| With sun and moon, as the guides to my love,
| Carrying the letters, of love and divine,
| Love written, with the blue of the sky,
| On never-ending stretches of stratus clouds,
| 
| Oh, you celestial nymph! Where are you?
| Bless this gallivanting soul with your grace!
| Longing for your glance, in the waves of life,
| Will you be my star and guide me to haven?
| 
| The blades of grass, the tenderly mint,
| The sparkle of garnets, the Bells of Ireland,
| The brightest of parakeets, the shades of leaves,
| Nothing matches the green of your clothes,
| 
| The petals of a rose, the face of mars,
| The brightest scarlets, the ravishing Gulmohar,
| The spiciest chillies, the sparkle of rubies,
| Nothing matches the red of your blush,
| 
| The embers of flame, the light of a Diya,
| The glitter of gold, the charming tulips,
| The shade of turmeric, the light streaks of dawn,
| Nothing matches the yellow of your glow,
| 
| The shades of violet, the limitless sea,
| The endless sky, the sparkle of sapphire,
| The face of Neptune, the adorable Smurfs,
| Nothing matches the blue of your eyes,
| 
| The emptiness of space, the kajal of your eyes,
| The feathers of a raven, the darkest of nights,
| The night tulips, the sharpest obsidian,
| Nothing matches the black of your hair,
| 
| The flawless cumulus, the ravishing jasmine,
| The foam on the waves, the teeth of a baby,
| The purest of milk, the flags of peace,
| Nothing matches the white of your heart,
| 
| My Geetanjali of music, My Ponanjali of dreams,
| My Pushpanjali of heart, My Kavitanjali of beauty,
| I ask you, with all the courage in the world,
| Will you be my bride? Oh, Nymphadora!
