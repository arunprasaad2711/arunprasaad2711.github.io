Ebb and Flow
============

| There we were, on that one fine day,
| Our stars aligned, and we saw a glimmer,
| Is this real? Our hearts yearned to know,
| This can be, our hearts thought so.
| 
| There were moments, that were quite hopeful,
| It felt real; we did see the change,
| Unlike the past, filled with pain and scars,
| We did see, something we dreamt of.
| 
| Few weeks pass, and it was bliss,
| Many a word was spoken and exchanged,
| Dreams and wishes, smiles and laughter,
| Pasts and futures, fears and secrets.
| 
| Are we finite? That we ran out of words?
| Hours of calls became rushed inquiries.
| In search of a meaningful banter,
| Did we forget, the sweetness of malarkey?
| 
| Is it time? The culprit behind the change?
| Did we change? And ran out of words?
| Is it fear? That holds us back now?
| Did we stop? When the glimmer left us?
| 
| I do wish that this is a phase,
| The ebbing phase, after a flowing phase,
| I hope that you too see it this way,
| And I hope that we flow again soon!
